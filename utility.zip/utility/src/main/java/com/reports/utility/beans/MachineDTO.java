/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class MachineDTO {

	private String machineId;
	private String pin;
	private String make;
	private String type;
	private String model;
	private String deviceId;
	private String serialNumber;
	private String currentConfig;
	private String lastConfig;
	
	
	/**
	 * @return the machineId
	 */
	public String getMachineId() {
		return machineId;
	}
	/**
	 * @param machineId the machineId to set
	 */
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}
	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}
	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * @return the deviceId
	 */
	public String getDeviceId() {
		return deviceId;
	}
	/**
	 * @param deviceId the deviceId to set
	 */
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the currentConfig
	 */
	public String getCurrentConfig() {
		return currentConfig;
	}
	/**
	 * @param currentConfig the currentConfig to set
	 */
	public void setCurrentConfig(String currentConfig) {
		this.currentConfig = currentConfig;
	}
	/**
	 * @return the lastConfig
	 */
	public String getLastConfig() {
		return lastConfig;
	}
	/**
	 * @param lastConfig the lastConfig to set
	 */
	public void setLastConfig(String lastConfig) {
		this.lastConfig = lastConfig;
	}
	
	
	
}
