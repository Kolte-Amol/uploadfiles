/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class IccIdBean {
	
	private String commGtwyId;
	private String IccId;
	private String activationDate;
	private String expirationDate;
	private String hdwrPkgId;
	private String machId;
	private String machIdNum;
	private String nodeId;
	private String dvcId;
	private String dvcNum;
	private String lastCommTS;
	private String licenseType;
	private String registrationStatus;
	
	/**
	 * @return the commGtwyId
	 */
	public String getCommGtwyId() {
		return commGtwyId;
	}
	/**
	 * @param commGtwyId the commGtwyId to set
	 */
	public void setCommGtwyId(String commGtwyId) {
		this.commGtwyId = commGtwyId;
	}
	/**
	 * @return the iccId
	 */
	public String getIccId() {
		return IccId;
	}
	/**
	 * @param iccId the iccId to set
	 */
	public void setIccId(String iccId) {
		IccId = iccId;
	}
	/**
	 * @return the activationDate
	 */
	public String getActivationDate() {
		return activationDate;
	}
	/**
	 * @param activationDate the activationDate to set
	 */
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	/**
	 * @return the hdwrPkgId
	 */
	public String getHdwrPkgId() {
		return hdwrPkgId;
	}
	/**
	 * @param hdwrPkgId the hdwrPkgId to set
	 */
	public void setHdwrPkgId(String hdwrPkgId) {
		this.hdwrPkgId = hdwrPkgId;
	}
	/**
	 * @return the machId
	 */
	public String getMachId() {
		return machId;
	}
	/**
	 * @param machId the machId to set
	 */
	public void setMachId(String machId) {
		this.machId = machId;
	}
	/**
	 * @return the machIdNum
	 */
	public String getMachIdNum() {
		return machIdNum;
	}
	/**
	 * @param machIdNum the machIdNum to set
	 */
	public void setMachIdNum(String machIdNum) {
		this.machIdNum = machIdNum;
	}
	/**
	 * @return the dvcId
	 */
	public String getDvcId() {
		return dvcId;
	}
	/**
	 * @param dvcId the dvcId to set
	 */
	public void setDvcId(String dvcId) {
		this.dvcId = dvcId;
	}
	/**
	 * @return the dvcNum
	 */
	public String getDvcNum() {
		return dvcNum;
	}
	/**
	 * @param dvcNum the dvcNum to set
	 */
	public void setDvcNum(String dvcNum) {
		this.dvcNum = dvcNum;
	}
	/**
	 * @return the nodeId
	 */
	public String getNodeId() {
		return nodeId;
	}
	/**
	 * @param nodeId the nodeId to set
	 */
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	/**
	 * @return the lastCommTS
	 */
	public String getLastCommTS() {
		return lastCommTS;
	}
	/**
	 * @param lastCommTS the lastCommTS to set
	 */
	public void setLastCommTS(String lastCommTS) {
		this.lastCommTS = lastCommTS;
	}
	/**
	 * @return the expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}
	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	/**
	 * @return the licenseType
	 */
	public String getLicenseType() {
		return licenseType;
	}
	/**
	 * @param licenseType the licenseType to set
	 */
	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}
	/**
	 * @return the registrationStatus
	 */
	public String getRegistrationStatus() {
		return registrationStatus;
	}
	/**
	 * @param registrationStatus the registrationStatus to set
	 */
	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}
	
	
}
