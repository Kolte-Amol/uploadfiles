/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class AccountUsersBean {
	
	private String accountId;
	private String usersName;
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the usersName
	 */
	public String getUsersName() {
		return usersName;
	}
	/**
	 * @param usersName the usersName to set
	 */
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	

}
