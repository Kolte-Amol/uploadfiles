/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class MachOrgBean {
	
	 private String trmNum; 
	 private String imei;
	 private String iccid;
	 private String msisdn;
	 private String imsi;
	 private String pin;	
	 private String cntry;
	 private String orgId;
	 private String OrgNm;
	/**
	 * @return the trmNum
	 */
	public String getTrmNum() {
		return trmNum;
	}
	/**
	 * @param trmNum the trmNum to set
	 */
	public void setTrmNum(String trmNum) {
		this.trmNum = trmNum;
	}
	/**
	 * @return the imei
	 */
	public String getImei() {
		return imei;
	}
	/**
	 * @param imei the imei to set
	 */
	public void setImei(String imei) {
		this.imei = imei;
	}
	/**
	 * @return the iccid
	 */
	public String getIccid() {
		return iccid;
	}
	/**
	 * @param iccid the iccid to set
	 */
	public void setIccid(String iccid) {
		this.iccid = iccid;
	}
	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}
	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	/**
	 * @return the imsi
	 */
	public String getImsi() {
		return imsi;
	}
	/**
	 * @param imsi the imsi to set
	 */
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the cntry
	 */
	public String getCntry() {
		return cntry;
	}
	/**
	 * @param cntry the cntry to set
	 */
	public void setCntry(String cntry) {
		this.cntry = cntry;
	}
	/**
	 * @return the orgId
	 */
	public String getOrgId() {
		return orgId;
	}
	/**
	 * @param orgId the orgId to set
	 */
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	/**
	 * @return the orgNm
	 */
	public String getOrgNm() {
		return OrgNm;
	}
	/**
	 * @param orgNm the orgNm to set
	 */
	public void setOrgNm(String orgNm) {
		OrgNm = orgNm;
	}
	 
	 

}
