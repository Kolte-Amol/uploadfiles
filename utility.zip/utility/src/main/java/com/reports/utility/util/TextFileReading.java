/**
 *
 */
package com.reports.utility.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author BK93287
 *
 */
public class TextFileReading {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 try {
	            FileReader reader = new FileReader("C://AMOL KOLTE ANALYSIS DOCS//Anna Defect//test.txt");
	            BufferedReader bufferedReader = new BufferedReader(reader);

	            String line;
	            int count = 1;

	            while ((line = bufferedReader.readLine()) != null) {
	                String line2=line.toString().trim()+",";
	            //	String line2="'"+line.toString().trim()+"'"+",";
	            	/*StringBuilder line2= new StringBuilder();
					line2.append('"');
					line2.append(line.toString().trim());
					line2.append('"');
					line2.append(',');*/
	               System.out.print(line2);
	               count++;
	            }
	            reader.close();
	            System.out.print(""+count);

	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	}

}
