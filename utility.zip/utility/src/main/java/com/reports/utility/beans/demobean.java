package com.reports.utility.beans;

/**
 * Created by Bk93287 on 7/28/2016.
 */
public class demobean {
    private String getwayId;
    private String getwayType;
    private String imei;
    private String iccid;
    private String msisdn;
    private String imsi;
    private String trmid;
    private String trmnum;
    private String eqipid;
    private String registration;
    private String coid;
    private String pin;
    private String config;
    private String nodeId;
    private String lastcommtp;

    public String getGetwayId() {
        return getwayId;
    }

    public void setGetwayId(String getwayId) {
        this.getwayId = getwayId;
    }

    public String getGetwayType() {
        return getwayType;
    }

    public void setGetwayType(String getwayType) {
        this.getwayType = getwayType;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getTrmid() {
        return trmid;
    }

    public void setTrmid(String trmid) {
        this.trmid = trmid;
    }

    public String getTrmnum() {
        return trmnum;
    }

    public void setTrmnum(String trmnum) {
        this.trmnum = trmnum;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public String getCoid() {
        return coid;
    }

    public void setCoid(String coid) {
        this.coid = coid;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getEqipid() {
        return eqipid;
    }

    public void setEqipid(String eqipid) {
        this.eqipid = eqipid;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getLastcommtp() {
        return lastcommtp;
    }

    public void setLastcommtp(String lastcommtp) {
        this.lastcommtp = lastcommtp;
    }
}

