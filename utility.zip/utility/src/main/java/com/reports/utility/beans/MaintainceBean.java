/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class MaintainceBean {
	
	public String machId;
	public String pin;
	public String machineNM;
	public String nodeId;
	public String accountId;
	public String accountNm;
	public String equipGrpNm;
	public String engineHrs;
	public String lastUpdatedTs;
	private String usersName;
	
	
	
	public String getMachId() {
		return machId;
	}
	public void setMachId(String machId) {
		this.machId = machId;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getMachineNM() {
		return machineNM;
	}
	public void setMachineNM(String machineNM) {
		this.machineNM = machineNM;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountNm() {
		return accountNm;
	}
	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}
	public String getEquipGrpNm() {
		return equipGrpNm;
	}
	public void setEquipGrpNm(String equipGrpNm) {
		this.equipGrpNm = equipGrpNm;
	}
	public String getEngineHrs() {
		return engineHrs;
	}
	public void setEngineHrs(String engineHrs) {
		this.engineHrs = engineHrs;
	}
	public String getLastUpdatedTs() {
		return lastUpdatedTs;
	}
	public void setLastUpdatedTs(String lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}
	
	/**
	 * @return the usersName
	 */
	public String getUsersName() {
		return usersName;
	}
	/**
	 * @param usersName the usersName to set
	 */
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	
}
