/**
 * 
 */
package com.reports.utility.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.AccountUsersBean;
import com.reports.utility.beans.MaintainceBean;


/**
 * @author BK93287
 *
 */
public class MergeExcelReport {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 
	     
	     List<AccountUsersBean> list1=new ArrayList<AccountUsersBean>();
	     List<MaintainceBean> list2=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list3=new ArrayList<MaintainceBean>();
	  
	     
	 //--------------------------------- Import Excel With Org and Org owner details-----------------------------------------
	     
	     try{
	        	String FilePath = "C:/Excel-Reports/Users.xlsx";
	            FileInputStream fs = new FileInputStream(FilePath);
	            Workbook workbook =  new XSSFWorkbook(fs);
	            Sheet sheet = workbook.getSheetAt(0);
	            int totalNoOfRows = 322;
	            int totalNoOfCols = 2;

	            for (int r = 0; r < totalNoOfRows; r++) {
	                Row row=sheet.getRow(r);
	                AccountUsersBean mb= new AccountUsersBean();
	                for (int col = 0; col < totalNoOfCols; col++) {
	                    Cell cell=row.getCell(col);
	                    if(col==0){
	                    	if(cell!=null){
	                    		DataFormatter formatter = new DataFormatter();
	                            String accountNumber = formatter.formatCellValue(cell);	                           
	                    		 mb.setAccountId(""+accountNumber);
	                    	}	                       
	                    }else if(col==1){
	                        if(cell!=null){
	                            mb.setUsersName(cell.getStringCellValue());
	                        }
	                    }
	                }
	                System.out.println(""+mb.getAccountId()+"   "+mb.getUsersName());
	                list1.add(mb);
	            }
	            System.out.println(list1.size());
	        }catch (IOException e){
	            e.printStackTrace();
	        }
//-----------------------------------Import Excel for machine data-----------------------------------------------------------
	        
	        
	        try{
	        	String FilePath = "C:/Excel-Reports/178711.xlsx";
	            FileInputStream fs = new FileInputStream(FilePath);
	            Workbook workbook =  new XSSFWorkbook(fs);
	            Sheet sheet = workbook.getSheetAt(0);
	            int totalNoOfRows = 5188;
	            int totalNoOfCols = 8;

	            for (int r = 0; r < totalNoOfRows; r++) {
	                Row row=sheet.getRow(r);
	                MaintainceBean mb= new MaintainceBean();
	                for (int col = 0; col < totalNoOfCols; col++) {
	                    Cell cell=row.getCell(col);
	                    if(col==0){
	                    	if(cell!=null){
	                    		 mb.setMachId(cell.getStringCellValue());
	                    	}	                       
	                    }else if(col==1){
	                        if(cell!=null){
	                            mb.setPin(cell.getStringCellValue());
	                        }
	                    }else if(col==2){
	                    	if(cell!=null){
	                    		 mb.setMachineNM(cell.getStringCellValue());
	                    	}	  
	                    }else if(col==3){
	                        if(cell!=null){
	                            mb.setAccountNm(cell.getStringCellValue());
	                        }
	                    }else if(col==4){
	                        if(cell!=null){
	                            mb.setEquipGrpNm(cell.getStringCellValue());
	                        }

	                    }else if(col==5){
	                        if(cell!=null){
	                            mb.setEngineHrs(cell.getStringCellValue());
	                        }

	                    }else if(col==6){
	                        if(cell!=null){
	                            mb.setLastUpdatedTs(cell.getStringCellValue());
	                        }
	                    }
	                    else if(col==7){
	                        if(cell!=null){
	                        	DataFormatter formatter = new DataFormatter();
	                            String accountNumber = formatter.formatCellValue(cell);	                           
	                    		 mb.setAccountId(""+accountNumber);
	                        }
	                    }
	                }
	                list2.add(mb);
	            }
	            System.out.println(list2.size());
	        }catch (IOException e){
	            e.printStackTrace();
	        }
	  //---------------------------------------Merge Code-------------------------------------------------------   
	        
	        
	        try{
	        	
	        	for (MaintainceBean dm:list2) {
	        		
	        		if(!(dm.getAccountId().equalsIgnoreCase("NA"))){
	        			for(AccountUsersBean user :list1){
	        				int mbOrgId = Integer.parseInt(dm.getAccountId().toString().trim());
	        				int userOrgId = Integer.parseInt(user.getAccountId().toString().trim());
	        				if (mbOrgId == userOrgId){
	        					dm.setUsersName(user.getUsersName().toString().trim());
	        				}
	        			}
	        		}
	        		
	        		list3.add(dm);	        		
	        	}
	        	
	        	System.out.println(list3.size());
	        	
	        }catch (Exception e){
	        	e.printStackTrace();
	        }
	        
	  //------------------------------Generate Excel -------------------------------------------------
	        try{
	            String FILE_PATH = "C:/Excel-Reports/Machine Data.xlsx";
	            Workbook workbook = new XSSFWorkbook();

	            Sheet sheet = workbook.createSheet("report");

	            Row row;
	            int rowid = 0;
	           
	            row = sheet.createRow(rowid++);

	            row.createCell(0).setCellValue("MACH_ID");
	            row.createCell(1).setCellValue("MACHINE");
	            row.createCell(2).setCellValue("MACHINE NAME");
	            row.createCell(3).setCellValue("THIRD PARTY DEALER");
	            row.createCell(4).setCellValue("EQUIPMENT GROUPS");
	            row.createCell(5).setCellValue("ENGINE HOURS");
	            row.createCell(6).setCellValue("LAST UPDATED TIME STAMP");
	            row.createCell(7).setCellValue("ORG_ID");
	            row.createCell(8).setCellValue("ORG_OWNER");
	           
	            for (MaintainceBean dm:list3) {
	                row = sheet.createRow(rowid++);
	                row.createCell(0).setCellValue(dm.getMachId());
	                row.createCell(1).setCellValue(dm.getPin());
	                row.createCell(2).setCellValue(dm.getMachineNM());
	                row.createCell(3).setCellValue(dm.getAccountNm());
	                row.createCell(4).setCellValue(dm.getEquipGrpNm());
	                row.createCell(5).setCellValue(dm.getEngineHrs());
	                row.createCell(6).setCellValue(dm.getLastUpdatedTs());	
	                row.createCell(7).setCellValue(dm.getAccountId());
	                row.createCell(8).setCellValue(dm.getUsersName());
	            }

	            try {
	                FileOutputStream fos = new FileOutputStream(FILE_PATH);
	                workbook.write(fos);
	                fos.close();

	                System.out.println(FILE_PATH + " is successfully written");
	            } catch (FileNotFoundException e) {
	                e.printStackTrace();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }

	        }catch (Exception e){
	        	e.printStackTrace();
	        }    

	}

}
