/**
 * 
 */
package com.reports.utility.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.MachOrgBean;



/**
 * @author BK93287
 *
 */
public class OrgForMAchines {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Connection con = null;
	     Statement stmt = null;
	     ResultSet rs = null;
	     
	     try {
	            Class.forName("com.ibm.db2.jcc.DB2Driver");
	            try {
	                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
	                System.out.println("Connection established with the Database. ");
	            } catch(SQLException e) {
	                e.printStackTrace();
	            }
	        } catch(ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        
	        List<MachOrgBean> list1=new ArrayList<MachOrgBean>();
		     List<MachOrgBean> list2=new ArrayList<MachOrgBean>();
		     List<MachOrgBean> list3=new ArrayList<MachOrgBean>();
		     

	        try{

	            String FilePath = "C:/11.xlsx";
	            FileInputStream fs = new FileInputStream(FilePath);
	            Workbook workbook =  new XSSFWorkbook(fs);
	            Sheet sheet = workbook.getSheetAt(0);

	            int totalNoOfRows = 362;
	            int totalNoOfCols = 7;

	            for (int r = 0; r < totalNoOfRows; r++) {
	                Row row=sheet.getRow(r);
	                MachOrgBean mb= new MachOrgBean();
	                for (int col = 0; col < totalNoOfCols; col++) {
	                    Cell cell=row.getCell(col);
	                    if(col==0){
	                        mb.setTrmNum(cell.getStringCellValue());
	                    }else if(col==1){
	                    	
	                        if(cell!=null){
	                        	mb.setImei(cell.getStringCellValue());
	                        }
	                    }else if(col==2){
	                    	 if(cell!=null){
		                        	mb.setImsi(cell.getStringCellValue());
		                        }
	                    }else if(col==3){
	                    	if(cell!=null){
	                        	mb.setMsisdn(cell.getStringCellValue());
	                        }
	                    }else if(col==4){
	                        if(cell!=null){
	                            mb.setIccid(cell.getStringCellValue());
	                        }

	                    }else if(col==5){
	                    	if(cell!=null){
	                            mb.setPin(cell.getStringCellValue());
	                        }
	                    }else if(col==6){
	                    	if(cell!=null){
	                            mb.setCntry(cell.getStringCellValue());
	                        }
	                    }
	                }
	                list1.add(mb);
	            }
	            System.out.println(list1.size());
	        
	        	
	        }catch (Exception e) {
                e.printStackTrace();
	        	
	        }
	        
	//-----------------------------------------------------------------------------------
	        
	        if(con != null) {
		    	 try{
		    		 for (MachOrgBean dm:list1) {
		    			 if(dm.getTrmNum()!=null){
		    				 StringBuilder queryForNode = new StringBuilder();
			    			 queryForNode.append("SELECT * FROM U90JLKP.NN_TRM_DTL WHERE TRM_NUM ='"+dm.getTrmNum().toString().trim());
			    			 queryForNode.append("' WITH UR FOR READ ONLY;");
			    			 
			    			 System.out.println(queryForNode.toString());
		                     stmt = con.createStatement();
		                     rs =stmt.executeQuery(queryForNode.toString());
		                     
		                     if (rs.next()) {
		                    	 dm.setOrgId(""+rs.getInt("CO_ID"));
		                     }
		    			 }
		    			 
	                     list2.add(dm);
	                     
	                     stmt.close();
	                     rs.close();
		    		 }
		    		 System.out.println(list2.size());
		    		 
		    	 }catch(Exception e) {
	                 e.printStackTrace();
	             }
		    	 
		     }
		     
		//------------------------------------------------------------------------------------------
		     
		     if(con != null) {
		    	 try{
		    		 for (MachOrgBean dm:list2) {
		    			 if(dm.getOrgId()!=null){
		    				 StringBuilder queryForNode = new StringBuilder();
			    			 queryForNode.append("SELECT * FROM U90JLKP.ORG_ACCT WHERE ID="+dm.getOrgId().toString().trim());
			    			 queryForNode.append(" WITH UR FOR READ ONLY;");
			    			 
			    			 System.out.println(queryForNode.toString());
		                     stmt = con.createStatement();
		                     rs =stmt.executeQuery(queryForNode.toString());
		                     
		                     if (rs.next()) {
		                    	 dm.setOrgNm(""+rs.getString("ORG_NM"));
		                     } 
		    			 }	    			
	                     list3.add(dm);
	                     
	                     stmt.close();
	                     rs.close();
		    		 }
		    		 System.out.println(list3.size());
		    		 
		    	 }catch(Exception e) {
	                 e.printStackTrace();
	             }
		    	 
		     }
//------------------------------------------------------------------------------------------
		     try{
		            String FILE_PATH = "C:/Data.xlsx";
		            Workbook workbook = new XSSFWorkbook();

		            Sheet sheet = workbook.createSheet("report");

		            Row row;
		            int rowid = 0;
		           
		            row = sheet.createRow(rowid++);

		            row.createCell(0).setCellValue("DVC_NUM");
		            row.createCell(1).setCellValue("IMEI");
		            row.createCell(2).setCellValue("IMSI");
		            row.createCell(3).setCellValue("MSISDN");
		            row.createCell(4).setCellValue("ICCID");
		            row.createCell(5).setCellValue("COMM_ID_NUM");
		            row.createCell(6).setCellValue("COUNTRY");
		            row.createCell(7).setCellValue("ORG_ID");
		            row.createCell(8).setCellValue("ORG_NAME");
		           
		            for (MachOrgBean dm:list3) {
		                row = sheet.createRow(rowid++);
		                row.createCell(0).setCellValue(dm.getTrmNum());
		                row.createCell(1).setCellValue(dm.getImei());
		                row.createCell(2).setCellValue(dm.getImsi());
		                row.createCell(3).setCellValue(dm.getMsisdn());
		                row.createCell(4).setCellValue(dm.getIccid());
		                row.createCell(5).setCellValue(dm.getPin());
		                row.createCell(6).setCellValue(dm.getCntry());	  
		                row.createCell(7).setCellValue(dm.getOrgId());
		                row.createCell(8).setCellValue(dm.getOrgNm());
		            }

		            try {
		                FileOutputStream fos = new FileOutputStream(FILE_PATH);
		                workbook.write(fos);
		                fos.close();

		                System.out.println(FILE_PATH + " is successfully written");
		            } catch (FileNotFoundException e) {
		                e.printStackTrace();
		            } catch (IOException e) {
		                e.printStackTrace();
		            }

		        }catch (Exception e){
		        	e.printStackTrace();
		        }
	}

}
