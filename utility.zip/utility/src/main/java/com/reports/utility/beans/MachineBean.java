package com.reports.utility.beans;
/**
 * Created by BK93287 on 8/10/2016.
 */
public class MachineBean {
    private String pin;
    private String trmId;
    private String trmNum;
    private String license;
    private String ultimateCap;
    private String issue;
    private String actionReq;
    private String currentCfg;
    private String nodeID;
    private String dmc;

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getTrmId() {
        return trmId;
    }

    public void setTrmId(String trmId) {
        this.trmId = trmId;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public String getUltimateCap() {
        return ultimateCap;
    }

    public void setUltimateCap(String ultimateCap) {
        this.ultimateCap = ultimateCap;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getActionReq() {
        return actionReq;
    }

    public void setActionReq(String actionReq) {
        this.actionReq = actionReq;
    }

    public String getCurrentCfg() {
        return currentCfg;
    }

    public void setCurrentCfg(String currentCfg) {
        this.currentCfg = currentCfg;
    }

    public String getTrmNum() {
        return trmNum;
    }

    public void setTrmNum(String trmNum) {
        this.trmNum = trmNum;
    }

    public String getNodeID() {
        return nodeID;
    }

    public void setNodeID(String nodeID) {
        this.nodeID = nodeID;
    }

	public String getDmc() {
		return dmc;
	}

	public void setDmc(String dmc) {
		this.dmc = dmc;
	}
    
}
