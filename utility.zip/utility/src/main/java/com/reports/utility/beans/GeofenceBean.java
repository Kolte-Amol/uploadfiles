/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class GeofenceBean {
	
	private String orgID;
	private String boundryID;
	private String boundryName;
	private String diaplay;
	private String machineId;
	private String pin;
	private String activeInd;
	private String actvStartTs;
	private String actvEndTs;
	private String lastModBy;
	private String lastModTs;
	private String geofenceId;
	
	
	/**
	 * @return the orgID
	 */
	public String getOrgID() {
		return orgID;
	}
	/**
	 * @param orgID the orgID to set
	 */
	public void setOrgID(String orgID) {
		this.orgID = orgID;
	}
	/**
	 * @return the boundryID
	 */
	public String getBoundryID() {
		return boundryID;
	}
	/**
	 * @param boundryID the boundryID to set
	 */
	public void setBoundryID(String boundryID) {
		this.boundryID = boundryID;
	}
	/**
	 * @return the boundryName
	 */
	public String getBoundryName() {
		return boundryName;
	}
	/**
	 * @param boundryName the boundryName to set
	 */
	public void setBoundryName(String boundryName) {
		this.boundryName = boundryName;
	}
	/**
	 * @return the diaplay
	 */
	public String getDiaplay() {
		return diaplay;
	}
	/**
	 * @param diaplay the diaplay to set
	 */
	public void setDiaplay(String diaplay) {
		this.diaplay = diaplay;
	}
	/**
	 * @return the machineId
	 */
	public String getMachineId() {
		return machineId;
	}
	/**
	 * @param machineId the machineId to set
	 */
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the activeInd
	 */
	public String getActiveInd() {
		return activeInd;
	}
	/**
	 * @param activeInd the activeInd to set
	 */
	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}
	/**
	 * @return the actvStartTs
	 */
	public String getActvStartTs() {
		return actvStartTs;
	}
	/**
	 * @param actvStartTs the actvStartTs to set
	 */
	public void setActvStartTs(String actvStartTs) {
		this.actvStartTs = actvStartTs;
	}
	/**
	 * @return the actvEndTs
	 */
	public String getActvEndTs() {
		return actvEndTs;
	}
	/**
	 * @param actvEndTs the actvEndTs to set
	 */
	public void setActvEndTs(String actvEndTs) {
		this.actvEndTs = actvEndTs;
	}
	/**
	 * @return the lastModBy
	 */
	public String getLastModBy() {
		return lastModBy;
	}
	/**
	 * @param lastModBy the lastModBy to set
	 */
	public void setLastModBy(String lastModBy) {
		this.lastModBy = lastModBy;
	}
	/**
	 * @return the lastModTs
	 */
	public String getLastModTs() {
		return lastModTs;
	}
	/**
	 * @param lastModTs the lastModTs to set
	 */
	public void setLastModTs(String lastModTs) {
		this.lastModTs = lastModTs;
	}
	/**
	 * @return the geofenceId
	 */
	public String getGeofenceId() {
		return geofenceId;
	}
	/**
	 * @param geofenceId the geofenceId to set
	 */
	public void setGeofenceId(String geofenceId) {
		this.geofenceId = geofenceId;
	}
	
	
	
}
