/**
 * 
 */
package com.reports.utility.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.deere.api.axiom.generated.v3.Collection;
import com.deere.api.axiom.generated.v3.Machine;
import com.deere.api.axiom.generated.v3.Resource;
import com.deere.api.axiom.generated.v3.Terminal;
import com.reports.utility.beans.MachineDTO;

/**
 * @author BK93287
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Test t= new Test();
		
		t.testURI(t);
	

	}
	
	public void testURI(Test t){
		List<String> machineids = new ArrayList<String>();
		try {
            FileReader reader = new FileReader("C://AMOL KOLTE ANALYSIS DOCS//Anna Defect//edit.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;
            int count = 1;

            while ((line = bufferedReader.readLine()) != null) {   
            	
            	machineids.add(line.toString().trim());
            }
            reader.close();
            System.out.print(""+count);

        } catch (IOException e) {
            e.printStackTrace();
        }
		
		
		List<MachineDTO> machines = new ArrayList();
		int i=0;
		for(String st : machineids){
			
			if(i>224){
				final String uri = "https://terminalws.deere.com/TerminalComponent/api/equipments/machines?id="+
						st.trim()+"&embed=machineAssociatedDevices";
				System.out.println(""+uri);
		        RestTemplate restTemplate = new RestTemplate();
		        ResponseEntity<Collection> result=null;
				try {
					result = restTemplate.exchange(uri, HttpMethod.GET, 
							new HttpEntity<Object>(t.createHeaders()), Collection.class);
				} catch (RestClientException e) {
					// TODO Auto-generated catch block
					System.out.println("@@@@@@@@"+uri);
					e.printStackTrace();								
				}
		        
		        Collection col = result.getBody();
		        List<JAXBElement<? extends Resource>> resources = col.getResources();
		        
		        resources.forEach(resource ->{
		        	Machine value = (Machine) resource.getValue();
		        	MachineDTO machine = new MachineDTO();
		        	
		        	machine.setMachineId(""+value.getId());
		        	machine.setPin(""+value.getVin());
		        	if(value.getMake()!=null){
		        		machine.setMake(""+value.getMake().getName());
		        	}
		        	if(value.getModel()!=null){
		        		machine.setModel(""+value.getModel().getName());
		        	}	
		        	
		        	if(value.getCategory()!=null){
		        		machine.setType(""+value.getCategory().getName());
		        	}
		        	
		        	
		        	List<Terminal> terminal = value.getTerminals().getTerminals();
		        	
		        	terminal.forEach(serialNumber ->{
		        		if(serialNumber!=null){
		        			if(serialNumber.getRegistrationStatus()!=null){
		        				if(serialNumber.getRegistrationStatus().equalsIgnoreCase("Registered") || 
				        				serialNumber.getRegistrationStatus().equalsIgnoreCase("Pending Registration")){
				        			machine.setDeviceId(""+serialNumber.getId());
				        			machine.setSerialNumber(""+serialNumber.getSerialNumber());
//					        		deviceids.append(""+serialNumber.getId()+",");
				        		}
		        			}
		        		}
		        		
		        	});
		        	
		        	machines.add(machine);
		        });	 
			}
			
			
	        
	        System.out.println(""+i);
	        i++;
		}
		
	}
	
	@SuppressWarnings("serial")
	public HttpHeaders createHeaders(){
		   return new HttpHeaders() {{
		         String auth = "BK93287" + ":" + "jdlink24";
		         byte[] encodedAuth = Base64.encodeBase64( 
		            auth.getBytes(Charset.forName("US-ASCII")) );
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
	}

}
