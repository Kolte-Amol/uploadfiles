/**
 * 
 */
package com.reports.utility.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.deere.api.axiom.generated.v3.Collection;
import com.deere.api.axiom.generated.v3.License;
import com.deere.api.axiom.generated.v3.Licenses;
import com.deere.api.axiom.generated.v3.ModularTelematicsGateway;
import com.deere.api.axiom.generated.v3.Resource;
import com.reports.utility.beans.IccIdBean;


/**
 * @author BK93287
 *
 */
public class GetICCIDDataReport {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GetICCIDDataReport getICCIDDataReport = new GetICCIDDataReport();
		

		getICCIDDataReport.generateExcel(getICCIDDataReport.getLastCallinTS(
				getICCIDDataReport.getConnectionForNodeDB(), getICCIDDataReport.getLicenseActvDate(getICCIDDataReport,
						getICCIDDataReport.getGetwayDetails(getICCIDDataReport.getConnectionForAuroraDB(),
								getICCIDDataReport.getFileData()))));
				
	}
	
	

	public String getFileData(){
		
		StringBuilder iccIds = new StringBuilder();
		try {
            FileReader reader = new FileReader("C://iccids.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
            

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                iccIds.append("'");
            	iccIds.append(line.toString().trim());
            	iccIds.append("'");
            	iccIds.append(",");               
            }
            reader.close();           

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(iccIds);
		return iccIds.substring(0, (iccIds.length()-1)).toString().trim();
	}
	
	public Connection getConnectionForAuroraDB(){
		Connection con = null;
		try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://dm-aurora-aws-1.c0cixceidvey.us-east-1.rds.amazonaws.com:3306/u90edm", "BK93287", "BK93287PROD");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
		return con;		
	}
	
	public List<IccIdBean> getGetwayDetails(Connection conn, String string){
		List <IccIdBean> list = new ArrayList<IccIdBean>();
		 if(conn != null){
	        	
	            try {
	            	StringBuilder queryForNode = new StringBuilder();
	            	
	            	queryForNode.append("SELECT CG.COMM_GTWY_ID, CG.ICCID, HDX.HDWR_PKG_ID, MHP.MACH_ID, MFO.MACH_ID_NUM, MFO.NODE_ID, HPDX.DVC_ID, TIF.DVC_NUM ");
	            	queryForNode.append("FROM U90EDM.COMM_GTWY CG LEFT JOIN U90EDM.HDWR_PKG_GTWY_XREF HDX ON HDX.COMM_GTWY_ID = CG.COMM_GTWY_ID ");
	            	queryForNode.append("LEFT JOIN U90EDM.MACH_HDWR_PKG MHP ON MHP.HDWR_PKG_ID = HDX.HDWR_PKG_ID ");
	            	queryForNode.append("LEFT JOIN U90EDM.MACH_INFO MFO ON MFO.MACH_ID = MHP.MACH_ID ");
	            	queryForNode.append("LEFT JOIN U90EDM.HDWR_PKG_DVC_XREF HPDX ON HPDX.HDWR_PKG_ID = HDX.HDWR_PKG_ID ");
	            	queryForNode.append("LEFT JOIN U90EDM.TRM_INFO TIF ON TIF.DVC_ID = HPDX.DVC_ID ");
	            	queryForNode.append("WHERE ICCID IN ("+string.toString().trim()+") and mhp.actv_asscn_ind = 'Y' and TIF.DVC_TYP_ID = 3");
	            	
	            	System.out.println(queryForNode.toString());
	            	Statement stmt = conn.createStatement();
	            	ResultSet rs =stmt.executeQuery(queryForNode.toString());
	                while(rs.next()){
	                	IccIdBean bean =new IccIdBean();
	                	
	                	bean.setCommGtwyId(rs.getString("COMM_GTWY_ID"));
	                	bean.setIccId(rs.getString("ICCID"));
	                	bean.setHdwrPkgId(rs.getString("HDWR_PKG_ID"));
                   	 	bean.setMachId(rs.getString("MACH_ID"));
                   	 	bean.setMachIdNum(rs.getString("MACH_ID_NUM"));
                   	 	bean.setNodeId(rs.getString("NODE_ID"));
                   	 	bean.setDvcId(rs.getString("DVC_ID"));
                   	 	bean.setDvcNum(rs.getString("DVC_NUM"));
	                	list.add(bean);	               	 
	                }
	                System.out.println(list.size());
	                stmt.close();
	                rs.close(); 
	                conn.close();
	            }catch(Exception e) {
	                e.printStackTrace();
	            }
	          }		
		return list;		
	}
	
	public List<IccIdBean> getLicenseActvDate(GetICCIDDataReport getICCIDDataReport,List<IccIdBean> list){
		
		List <IccIdBean> list1 = new ArrayList<IccIdBean>();	
		List <IccIdBean> list2 = new ArrayList<IccIdBean>();
		final String uri = "https://terminalws.deere.com/TerminalComponent/api/equipments/terminals?serialNumber="+
		getICCIDDataReport.createCommSeperatedString(list)+"&embed=licenses,subscriptions";
		try {
		
			System.out.println(""+uri);
		    RestTemplate restTemplate = new RestTemplate();
	        ResponseEntity <Collection> result = restTemplate.exchange(uri, HttpMethod.GET, 
	        		new HttpEntity<Object>(getICCIDDataReport.createHeaders()), Collection.class);
	        
	        Collection col = result.getBody();
	        
	        List<JAXBElement<? extends Resource>> resources = col.getResources();
	        for (JAXBElement<? extends Resource> jaxbElement : resources) {
	        	IccIdBean ibean = new IccIdBean();
				ModularTelematicsGateway value = (ModularTelematicsGateway)jaxbElement.getValue();
				Licenses licenses = value.getLicenses();
				List<License> licenses2 = licenses.getLicenses();
				System.out.println(value.getId());
				ibean.setDvcNum(value.getSerialNumber());
				ibean.setRegistrationStatus(""+value.getRegistrationStatus());
				for (License license : licenses2) {
					if(license.getType().equalsIgnoreCase("JDLINK_ULTIMATE") || 
							license.getType().equalsIgnoreCase("JDLINK_ULTIMATE_DEMO") || 
							license.getType().equalsIgnoreCase("JDLINK_ULTIMATE_FIELD")){
						ibean.setLicenseType(""+license.getType());
						ibean.setActivationDate(""+license.getStartDate());
						ibean.setExpirationDate(""+license.getEndDate());
					}					
				}
				list1.add(ibean);
			}
	        
	        list2 = getICCIDDataReport.mergeLicenseAndMachine(list1, list);
	        
		}catch(Exception e){
			e.printStackTrace();
		}
		return list2;
		
	}
	
	public List<IccIdBean> mergeLicenseAndMachine(List<IccIdBean> list1,
			List<IccIdBean> list) {
		List<IccIdBean> mergedList = new ArrayList<IccIdBean>();
		
		for(IccIdBean bean : list){
			for(IccIdBean ibean : list1){
				if(ibean.getDvcNum().equalsIgnoreCase(bean.getDvcNum())){
					bean.setRegistrationStatus(""+ibean.getRegistrationStatus());
					bean.setLicenseType(""+ibean.getLicenseType());
					bean.setActivationDate(""+ibean.getActivationDate());
					bean.setExpirationDate(""+ibean.getExpirationDate());
				}
			}
			mergedList.add(bean);
		}
		
		System.out.println(mergedList.size());
		return mergedList;
	}



	public String createCommSeperatedString(List<IccIdBean> list){
		StringBuilder trmNums = new StringBuilder();
		for (IccIdBean bean:list) {
			if(bean.getDvcNum()!=null){
				trmNums.append(bean.getDvcNum().toString().trim());
				trmNums.append(",");
			}
		}
		return trmNums.substring(0, (trmNums.length()-1)).toString().trim();
	}
	
	@SuppressWarnings("serial")
	public HttpHeaders createHeaders(){
		   return new HttpHeaders() {{
		         String auth = "BK93287" + ":" + "jdlink24";
		         byte[] encodedAuth = Base64.encodeBase64( 
		            auth.getBytes(Charset.forName("US-ASCII")) );
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
	}
	public Connection getConnectionForNodeDB(){
		Connection con = null;
		try {
			 Class.forName("com.ibm.db2.jcc.DB2Driver");
	            try {
	                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
	                System.out.println("Connection established with the Database. ");
	            } catch(SQLException e) {
	                e.printStackTrace();
	            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
		return con;		
	}
	
	
	private List<IccIdBean> getLastCallinTS(
			Connection con, List<IccIdBean> list) {
		List <IccIdBean> list1 = new ArrayList<IccIdBean>();
		if(con != null) {
			 try {
				 for (IccIdBean bean:list) {
					 if(bean.getNodeId()!=null){

	                        int nodeid=Integer.parseInt(bean.getNodeId().toString().trim());
	                        StringBuilder nodename = new StringBuilder();
	                        if(nodeid<11){
	                            nodename.append("J9000"+(nodeid-1));
	                            nodename.append("P");
	                        }else{
	                            nodename.append("J900"+(nodeid-1));
	                            nodename.append("P");
	                        }

	                        StringBuilder queryForNode = new StringBuilder();
	                        queryForNode.append("SELECT * FROM "+nodename.toString().trim());
	                        queryForNode.append(".EQIP_CALL_IN_INFO ECL WHERE ECL.MACH_ID="+bean.getMachId().toString().trim());
	                        queryForNode.append(" order by ECL.CPTR_TS desc fetch first row only;");

	                        Statement stmt = con.createStatement();
	                        System.out.println(queryForNode.toString());
	                        ResultSet rs = stmt.executeQuery(queryForNode.toString());

	                        if(rs.next()){
	                        	bean.setLastCommTS(rs.getString("CPTR_TS"));
	                        }
	                        stmt.close();
	       	             	rs.close();
					 }
					 list1.add(bean);
				 }
				 System.out.println(list1.size());
				 con.close();				
			 }catch(Exception e) {
	                e.printStackTrace();
	         }
		}
		
		return list1;
	}	
	
	public void generateExcel(List<IccIdBean> list){
		
		try{
            String FILE_PATH = "C:/Iccid_report.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");
            //Create row object
            Row row;
            int rowid = 0;
            row = sheet.createRow(rowid++);

            row.createCell(0).setCellValue("ICCID");
            row.createCell(1).setCellValue("GTWY_ID");
            row.createCell(2).setCellValue("MACH_ID");
            row.createCell(3).setCellValue("PIN");
            row.createCell(4).setCellValue("DVC_ID");
            row.createCell(5).setCellValue("TRM_NUM");
            
            row.createCell(6).setCellValue("ACTIVATION_TS");
            row.createCell(7).setCellValue("EXPIRATION_TS");
            row.createCell(8).setCellValue("REGISTRATION_STATUS");
            row.createCell(9).setCellValue("LICENSE_TYPE");
            row.createCell(10).setCellValue("LAST_COMM_TS");
            
            for (IccIdBean bean:list) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(bean.getIccId());
                row.createCell(1).setCellValue(bean.getCommGtwyId());
                row.createCell(2).setCellValue(bean.getMachId());
                row.createCell(3).setCellValue(bean.getMachIdNum());
                row.createCell(4).setCellValue(bean.getDvcId());
                row.createCell(5).setCellValue(bean.getDvcNum());
                
                row.createCell(6).setCellValue(bean.getActivationDate());
                row.createCell(7).setCellValue(bean.getExpirationDate());
                row.createCell(8).setCellValue(bean.getRegistrationStatus());
                row.createCell(9).setCellValue(bean.getLicenseType());
                row.createCell(10).setCellValue(bean.getLastCommTS());
            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){

        }
	}
	
}
