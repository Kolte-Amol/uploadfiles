/**
 * 
 */
package com.reports.utility.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.BoundryVertexBean;
import com.reports.utility.beans.GeofenceBean;
import com.reports.utility.beans.GeofenceDtlbean;


/**
 * @author BK93287
 *
 */
public class GetGeofenceDtl {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        StringBuilder sb = new StringBuilder();
        
        try {
            Class.forName("com.ibm.db2.jcc.DB2Driver");
            try {
                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
//----------------------------------------------------------------------------------------------------        
       
        List<GeofenceBean> list1 = new ArrayList<GeofenceBean>();
        List<GeofenceBean> list2 = new ArrayList<GeofenceBean>();
        List<GeofenceBean> list3 = new ArrayList<GeofenceBean>();
        
        List<BoundryVertexBean> vlist1 = new ArrayList<BoundryVertexBean>();
        List<GeofenceDtlbean> finaList = new ArrayList<GeofenceDtlbean>();
//----------------------------------------------------------------------------------------------------
        
        if(con != null){
            try {
            	
            	StringBuilder queryForNode = new StringBuilder();
            	
            	queryForNode.append("SELECT OABI.ORG_ID, BI.BNDRY_ID, BI.BNDRY_NM, BI.DSPLY, BE.EQIP_ID, MIF.MACH_ID_NUM, BE.ACTV_IND, ");
            	queryForNode.append("BE.ACTV_START_TS, BE.ACTV_END_TS, BE.LAST_MOD_BY, BI.LAST_MOD_TS, GEO.GEOFENCE_GRP_ID ");
            	queryForNode.append("FROM U90JLKP.ORG_ACCT_BNDRY_INFO OABI LEFT JOIN U90JLKP.BNDRY_INFO BI ON BI.BNDRY_ID = OABI.BNDRY_ID ");
            	queryForNode.append("LEFT JOIN U90JLKP.GEOFENCE_GRP GEO ON BI.BNDRY_ID = GEO.BNDRY_ID ");
            	queryForNode.append("LEFT JOIN U90JLKP.BNDRY_EQIP BE ON BI.BNDRY_ID = BE.BNDRY_ID ");
            	queryForNode.append("LEFT JOIN U90EDMP.MACH_INFO MIF ON BE.EQIP_ID = MIF.MACH_ID ");
            	queryForNode.append("WHERE BE.ACTV_IND ='Y' AND BI.DSPLY = 'Y' AND GEO.DEL = 'N' AND BE.EQIP_ID IS NOT NULL ");
            	queryForNode.append("ORDER BY OABI.ORG_ID ASC WITH UR FOR READ ONLY;");
            	
            	System.out.println(queryForNode.toString());
                stmt = con.createStatement();
                rs =stmt.executeQuery(queryForNode.toString());
                while(rs.next()){
                	GeofenceBean bean =new GeofenceBean();
                  	
                	bean.setOrgID(rs.getString("ORG_ID"));
                	bean.setBoundryID(rs.getString("BNDRY_ID"));
                	bean.setBoundryName(rs.getString("BNDRY_NM"));
                	bean.setDiaplay(rs.getString("DSPLY"));
                	bean.setMachineId(rs.getString("EQIP_ID"));
                	bean.setPin(rs.getString("MACH_ID_NUM"));
                	bean.setActiveInd(rs.getString("ACTV_IND"));
                	bean.setActvStartTs(rs.getString("ACTV_START_TS"));
                	bean.setActvEndTs(rs.getString("ACTV_END_TS"));
                	bean.setLastModBy(rs.getString("LAST_MOD_BY"));
                	bean.setLastModTs(rs.getString("LAST_MOD_TS"));
                	bean.setGeofenceId(rs.getString("GEOFENCE_GRP_ID"));
                	
                	sb.append(""+rs.getString("BNDRY_ID").toString().trim()+",");
                	
                	list1.add(bean);
               	 
                }
                System.out.println(list1.size());
                System.out.println(sb);
                stmt.close();
                rs.close();
            	
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
        
//---------------------------------------------------------------------------------------------------
        if(con != null){
        	 try {
             	
             	StringBuilder queryForNode = new StringBuilder();
             	queryForNode.append("SELECT * FROM U90JLKP.BNDRY_VERTEX BV ");
            	queryForNode.append("LEFT JOIN U90JLKP.VERTEX_TYP_DM VTD ON VTD.VERTEX_TYP_ID = BV.VERTEX_TYP_CD ");
            	queryForNode.append("WHERE BV.BNDRY_ID IN ("+sb.substring(0, sb.length()-1).toString().trim() +")");
            	queryForNode.append(" ORDER BY BV.BNDRY_ID, BV.BNDRY_VERTEX_SEQ_NUM ASC WITH UR FOR READ ONLY;");
            	System.out.println(queryForNode.toString());
            	
            	stmt = con.createStatement();
                rs =stmt.executeQuery(queryForNode.toString());
                while(rs.next()){
                	BoundryVertexBean bean =new BoundryVertexBean();
                	
                	bean.setBoundryID(rs.getString("BNDRY_ID"));
                	bean.setBoundryVerID(rs.getString("BNDRY_VERTEX_ID"));
                	bean.setVertypID(rs.getString("VERTEX_TYP_CD"));
                	bean.setVerTypDsc(rs.getString("VERTEX_TYP_DSC"));
                	bean.setBoundryVersq(rs.getString("BNDRY_VERTEX_SEQ_NUM"));
                	bean.setLat(rs.getString("LAT_QTY"));
                	bean.setLongg(rs.getString("LONG_QTY"));
                  	
                	
                	vlist1.add(bean);
               	 
                }
                System.out.println(vlist1.size());
                stmt.close();
                rs.close();
            	
        	 }catch(Exception e) {
                 e.printStackTrace();
             }
        }
//--------------------------------------------------------------------------------------------------
        
        if(list1!=null){
        	
        	for (GeofenceBean dm:list1) {
        		if(dm.getBoundryID()!=null) {
        			GeofenceDtlbean bean = new GeofenceDtlbean();
        			
        			bean.setOrgID(dm.getOrgID());
        			bean.setBoundryID(dm.getBoundryID());
        			bean.setBoundryName(dm.getBoundryName());
        			bean.setDiaplay(dm.getDiaplay());
        			bean.setMachineId(dm.getMachineId());
        			bean.setPin(dm.getPin());
        			bean.setActiveInd(dm.getActiveInd());
        			bean.setActvStartTs(dm.getActvStartTs());
        			bean.setActvEndTs(dm.getActvEndTs());
        			bean.setLastModBy(dm.getLastModBy());
        			bean.setLastModTs(dm.getLastModTs());
        			bean.setGeofenceId(dm.getGeofenceId());
        			
        		
        			
        			for (BoundryVertexBean vb:vlist1) {
        				if(dm.getBoundryID().equalsIgnoreCase(vb.getBoundryID())){
        					int sq = Integer.parseInt(vb.getBoundryVersq().toString().trim());
        					if(sq==0){
        						bean.setCenterLat(vb.getLat());
        						bean.setCenterLong(vb.getLongg());
        						
        						int vrtp = Integer.parseInt(vb.getVertypID().toString().trim());
        						
        						if(vrtp == 2){
        							bean.setGeofenceAreaTyp("Rectangle");
        							
        						}else if(vrtp == 3){
        							
        							bean.setGeofenceAreaTyp("Circle");
        						}
        						
        					}else if(sq==1){
        						bean.setBndVer1Lat(vb.getLat());
        						bean.setBndVer1Long(vb.getLongg());        						
        					}else if(sq==2){
        						bean.setBndVer2Lat(vb.getLat());
        						bean.setBndVer2Long(vb.getLongg());        						
        					}else if(sq==3){
        						bean.setBndVer3Lat(vb.getLat());
        						bean.setBndVer3Long(vb.getLongg());        						
        					}else if(sq==4){
        						bean.setBndVer4Lat(vb.getLat());
        						bean.setBndVer4Long(vb.getLongg());        						
        					}
        					
        				}
        			}
        			
        			finaList.add(bean);
        		}
        		
        	}
        	
        }
        
//-------------------------------------------------------------------------------------------
        try{
            String FILE_PATH = "C:/Geofence.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");

            Row row;
            int rowid = 0;
           
            row = sheet.createRow(rowid++);

            row.createCell(0).setCellValue("MACH_ID");
            row.createCell(1).setCellValue("PIN");
            row.createCell(2).setCellValue("ORG_ID");
            row.createCell(3).setCellValue("GEOFENCE_NAME");
            row.createCell(4).setCellValue("VISIBLE?");
            row.createCell(5).setCellValue("ACTIVE?");
            row.createCell(6).setCellValue("ACTVN_DT");            
            row.createCell(7).setCellValue("ACTVN_END_DT");
            row.createCell(8).setCellValue("GEOFENCE_ID");
            row.createCell(9).setCellValue("GEOFENCE_AREA_TYP");
            row.createCell(10).setCellValue("CENTER_LAT");
            row.createCell(11).setCellValue("CENTER_LONG");
            
            row.createCell(12).setCellValue("BNDRY_VERTEX_1_LAT");
            row.createCell(13).setCellValue("BNDRY_VERTEX_1_LONG");            
            row.createCell(14).setCellValue("BNDRY_VERTEX_2_LAT");
            row.createCell(15).setCellValue("BNDRY_VERTEX_2_LONG");
            row.createCell(16).setCellValue("BNDRY_VERTEX_3_LAT");
            row.createCell(17).setCellValue("BNDRY_VERTEX_3_LONG");
            row.createCell(18).setCellValue("BNDRY_VERTEX_4_LAT");
            row.createCell(19).setCellValue("BNDRY_VERTEX_4_LONG");
            
            row.createCell(20).setCellValue("LAST_MOD_BY");
            row.createCell(21).setCellValue("LAST_MOD_TS");
            row.createCell(22).setCellValue("boundry id");
            
            for (GeofenceDtlbean bean:finaList) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(bean.getMachineId());
                row.createCell(1).setCellValue(bean.getPin());
                row.createCell(2).setCellValue(bean.getOrgID());
                row.createCell(3).setCellValue(bean.getBoundryName().toString().trim());
                row.createCell(4).setCellValue(bean.getDiaplay());
                row.createCell(5).setCellValue(bean.getActiveInd());
                row.createCell(6).setCellValue(bean.getActvStartTs());                
                row.createCell(7).setCellValue(bean.getActvEndTs());
                row.createCell(8).setCellValue(bean.getGeofenceId());
                row.createCell(9).setCellValue(bean.getGeofenceAreaTyp());
                row.createCell(10).setCellValue(bean.getCenterLat());
                row.createCell(11).setCellValue(bean.getCenterLong());
                
                
                row.createCell(12).setCellValue(bean.getBndVer1Lat());
                row.createCell(13).setCellValue(bean.getBndVer1Long());
                row.createCell(14).setCellValue(bean.getBndVer2Lat());
                row.createCell(15).setCellValue(bean.getBndVer2Long());
                row.createCell(16).setCellValue(bean.getBndVer3Lat());
                row.createCell(17).setCellValue(bean.getBndVer3Long());
                row.createCell(18).setCellValue(bean.getBndVer4Lat());                
                row.createCell(19).setCellValue(bean.getBndVer4Long());
                
                row.createCell(20).setCellValue(bean.getLastModBy());
                row.createCell(21).setCellValue(bean.getLastModTs());
                row.createCell(22).setCellValue(bean.getBoundryID());
                
            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){
        	e.printStackTrace();
        }
        
	}
	
}
