package com.reports.utility.util;

import com.deere.api.axiom.generated.v3.Collection;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by st92564 on 7/5/2017.
 */
@Component
@PropertySource({ "classpath:resttemplate.properties" })
@Scope("prototype")
public class RestClient {
    RestTemplate restTemplate;
    @Autowired Environment env;

    private static final String MEDIA_TYPE_XML = "application/vnd.deere.axiom.v3+xml";

    public  <T > T  callRestServiceForXML(String requestURI, Object requestBody)  {
        restTemplate = new RestTemplate();

        ResponseEntity<T> responseEntity = null;
        try {
            responseEntity = (ResponseEntity<T>) restTemplate.exchange(requestURI, HttpMethod.GET,
                    new HttpEntity<Object>(requestBody, getHttpHeaders(env.getProperty("dm.rest.service.accept"),
                            env.getProperty("dm.rest.service.accept"))), Collection.class);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return (responseEntity != null && (responseEntity.getStatusCode() == HttpStatus.OK ||
                responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT)) ? responseEntity.getBody() : null;
    }

    private HttpHeaders getHttpHeaders(String mediaType, String contentType){
        String userId = env.getProperty("dm.rest.service.username");
        String password = env.getProperty("dm.rest.service.password");
        HttpHeaders headers = createHeaders(userId, password);
        headers.set("Accept",mediaType);
        return headers;

    }


    private <T> boolean isSuccess(ResponseEntity<T> responseEntity) {
        return responseEntity != null && responseEntity.hasBody() && (responseEntity.getStatusCode() == HttpStatus.OK || responseEntity.getStatusCode() == HttpStatus.PARTIAL_CONTENT);
    }

    private HttpHeaders createHeaders(String username, String password) {
        HttpHeaders headers = new HttpHeaders();
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        String authHeader = "Basic " + new String(encodedAuth);
        headers.set("Authorization", authHeader);
        return headers;
    }

}
