package com.reports.utility.util;
/**
 * Created by BK93287 on 8/10/2016.
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.MachineBean;


public class ReadAndWriteExcel {
    public static void main(String args[]){
        Connection con = null;

        List<MachineBean> machineBeanList=new ArrayList<MachineBean>();
      
        List<MachineBean> list1=new ArrayList<MachineBean>();
        List<MachineBean> list2=new ArrayList<MachineBean>();
        try{
            String FilePath = "C:/5E 5M 6D 6M.xlsx";
            FileInputStream fs = new FileInputStream(FilePath);
            Workbook workbook =  new XSSFWorkbook(fs);
            Sheet sheet = workbook.getSheetAt(0);

            int totalNoOfRows = 742;
            int totalNoOfCols = 9;

            for (int r = 0; r < totalNoOfRows; r++) {
                Row row=sheet.getRow(r);
                MachineBean mb= new MachineBean();
                for (int col = 0; col < totalNoOfCols; col++) {
                    Cell cell=row.getCell(col);
                    if(col==0){
                        mb.setPin(cell.getStringCellValue());
                    }else if(col==1){
                        if(cell!=null){
                            DataFormatter formatter = new DataFormatter();
                            String j_username = formatter.formatCellValue(cell);
                            mb.setTrmId(""+j_username);
                        }
                    }else if(col==2){
                        mb.setTrmNum(cell.getStringCellValue());
                    }else if(col==3){
                        if(cell!=null){
                            mb.setLicense(cell.getStringCellValue());
                        }
                    }else if(col==4){
                        if(cell!=null){
                            mb.setUltimateCap(cell.getStringCellValue());
                        }

                    }else if(col==5){
                        if(cell!=null){
                            mb.setIssue(cell.getStringCellValue());
                        }

                    }else if(col==6){
                        if(cell!=null){
                            mb.setActionReq(cell.getStringCellValue());
                        }
                    }else if(col==7){
                        if(cell!=null){
                            mb.setCurrentCfg(cell.getStringCellValue());
                        }
                    }else if(col==8){
                        if(cell!=null){
                        	DataFormatter formatter = new DataFormatter();
                            String node = formatter.formatCellValue(cell);
                            System.out.println(node);
                            mb.setNodeID(""+node);
                        }
                    }
                }
                machineBeanList.add(mb);
            }
            System.out.println(machineBeanList.size());
        }catch (IOException e){
            e.printStackTrace();
        }

 /*       try{
            for (MachineBean mb:machineBeanList) {
                String pin=mb.getPin().toString().trim();
                for (String str:stringList) {
                    if (pin.equalsIgnoreCase(str.toString().trim())){
                        mb.setUltimateCap("NO");
                        mb.setIssue("Machine is currently Inactive");
                        mb.setActionReq("Machine needs to be activated");
                    }

                }
                machineBeanList1.add(mb);

            }
        }catch (Exception e){
            e.printStackTrace();
        }*/
//-----------------------------------------------------------------------------------------------------
        try {
            Class.forName("com.ibm.db2.jcc.DB2Driver");
            try {
                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }

  /*      if(con != null) {
            try {
                int i=0;
                for (MachineBean dm:machineBeanList) {
                    if(dm.getPin()!=null && i>0) {
                        StringBuilder queryForNode = new StringBuilder();
                        System.out.println(dm.getPin());
                        queryForNode.append("SELECT DISTINCT(NTDL.TRM_ID) FROM U90JLKP.NN_TRM_DTL NTDL WHERE NTDL.PIN = '" + dm.getPin().toString().trim());
                        queryForNode.append("' WITH UR FOR READ ONLY;");
                        System.out.println(queryForNode.toString());
                        Statement stmt = con.createStatement();
                        ResultSet rs =stmt.executeQuery(queryForNode.toString());

                        if (rs.next()) {
                            dm.setTrmId(rs.getString("TRM_ID"));
                        }

                        stmt.close();
                        rs.close();
                    }
                    list1.add(dm);
                    i++;
                }
                System.out.println(list1.size());
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
//-----------------------------------------------------------------------------------------------------
        if(con != null) {
            try {
                int j=0;
                for (MachineBean dm:machineBeanList) {


                    if(dm.getTrmId()!=null) {
                        System.out.println(j);
                        if(j>=1){
                            System.out.println(dm.getTrmId());
                            StringBuilder queryForNode = new StringBuilder();
                            queryForNode.append("SELECT DISTINCT(VH.VER_NM) FROM U90EDMP.TRM_VER_HIST_SMRY VH WHERE VH.DVC_ID =" + dm.getTrmId().toString().trim());
                            queryForNode.append(" AND VH.VER_TYP_ID = 1 AND VH.STATUS = 'C' WITH UR FOR READ ONLY;");
                            System.out.println(queryForNode.toString());
                            Statement stmt = con.createStatement();
                            ResultSet rs =stmt.executeQuery(queryForNode.toString());

                            if (rs.next()) {
                                dm.setCurrentCfg(rs.getString("VER_NM"));
                            }
                            stmt.close();
                            rs.close();
                        }

                    }
                    list2.add(dm);
                    j++;
                }

                System.out.println(list1.size());
            }catch(Exception e) {
                e.printStackTrace();
            }
        }*/

//------------------------------------------------------------------------------------------------------
        if(con != null) {
            try {
                int j=0;
                for (MachineBean dm:machineBeanList) {


                    if(dm.getPin()!=null) {
                    	String ll= dm.getLicense().toString().trim();
                    	System.out.println(ll);
                    	if(ll.equalsIgnoreCase("ULTIMATE")){
                    		 System.out.println(j);
                             if(j>=1){
                                 System.out.println(dm.getPin());
                                 StringBuilder queryForNode = new StringBuilder();
                                 queryForNode.append("SELECT DISTINCT(MHF.DTL_MACH_CD) FROM U90EDMP.MACH_INFO MHF WHERE MHF.MACH_ID_NUM = '" + dm.getPin().toString().trim());
                                 queryForNode.append("' WITH UR FOR READ ONLY;");
                                 System.out.println(queryForNode.toString());
                                 Statement stmt = con.createStatement();
                                 ResultSet rs =stmt.executeQuery(queryForNode.toString());

                                 if (rs.next()) {
                                	 dm.setDmc(rs.getString("DTL_MACH_CD"));
                                 }
                                 stmt.close();
                                 rs.close();
                             }
                    	}
                    }
                    list2.add(dm);
                    j++;
                }

                System.out.println(list1.size());
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
        //------------------------------------------------------------------------------------------------------

        try{
            String FILE_PATH = "C:/Brazil report.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");

            Row row;
            int rowid = 0;
            for (MachineBean dm:list2) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(dm.getPin());
                row.createCell(1).setCellValue(dm.getTrmId());
                row.createCell(2).setCellValue(dm.getTrmNum());
                row.createCell(3).setCellValue(dm.getLicense());
                row.createCell(4).setCellValue(dm.getUltimateCap());
                row.createCell(5).setCellValue(dm.getIssue());
                row.createCell(6).setCellValue(dm.getActionReq());
                row.createCell(7).setCellValue(dm.getCurrentCfg());
                if(dm.getNodeID()!=null){
                	row.createCell(8).setCellValue(dm.getNodeID());
                }
                if(dm.getDmc()!=null){
                	row.createCell(9).setCellValue(dm.getDmc());
                }

            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){
        	e.printStackTrace();
        }
    }
}
