/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author Bk93287
 *
 */
public class BoundryVertexBean {
	
	private String boundryID;
	private String boundryVerID;
	private String lat;
	private String longg;
	private String boundryVersq;
	private String vertypID;
	private String verTypDsc;
	/**
	 * @return the boundryID
	 */
	public String getBoundryID() {
		return boundryID;
	}
	/**
	 * @param boundryID the boundryID to set
	 */
	public void setBoundryID(String boundryID) {
		this.boundryID = boundryID;
	}
	/**
	 * @return the boundryVerID
	 */
	public String getBoundryVerID() {
		return boundryVerID;
	}
	/**
	 * @param boundryVerID the boundryVerID to set
	 */
	public void setBoundryVerID(String boundryVerID) {
		this.boundryVerID = boundryVerID;
	}
	/**
	 * @return the lat
	 */
	public String getLat() {
		return lat;
	}
	/**
	 * @param lat the lat to set
	 */
	public void setLat(String lat) {
		this.lat = lat;
	}
	/**
	 * @return the longg
	 */
	public String getLongg() {
		return longg;
	}
	/**
	 * @param longg the longg to set
	 */
	public void setLongg(String longg) {
		this.longg = longg;
	}
	/**
	 * @return the boundryVersq
	 */
	public String getBoundryVersq() {
		return boundryVersq;
	}
	/**
	 * @param boundryVersq the boundryVersq to set
	 */
	public void setBoundryVersq(String boundryVersq) {
		this.boundryVersq = boundryVersq;
	}
	/**
	 * @return the verTypDsc
	 */
	public String getVerTypDsc() {
		return verTypDsc;
	}
	/**
	 * @param verTypDsc the verTypDsc to set
	 */
	public void setVerTypDsc(String verTypDsc) {
		this.verTypDsc = verTypDsc;
	}
	/**
	 * @return the vertypID
	 */
	public String getVertypID() {
		return vertypID;
	}
	/**
	 * @param vertypID the vertypID to set
	 */
	public void setVertypID(String vertypID) {
		this.vertypID = vertypID;
	}
	
		
}
