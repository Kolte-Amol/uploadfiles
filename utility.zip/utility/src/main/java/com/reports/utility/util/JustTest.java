/**
 * 
 */
package com.reports.utility.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.ConnectDevicesBean;



/**
 * @author BK93287
 *
 */
public class JustTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://dm-aurora-aws-1.c0cixceidvey.us-east-1.rds.amazonaws.com:3306/u90edm", "BK93287", "BK93287PROD");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        List<ConnectDevicesBean> list1 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list2 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list3 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list4 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list5 = new ArrayList<ConnectDevicesBean>();
        
        if(con != null){
        	
        try {
        	StringBuilder queryForNode = new StringBuilder();
        	
        	queryForNode.append("select * from u90edm.trm_info where dvc_typ_id = 10");
        	
        	System.out.println(queryForNode.toString());
            stmt = con.createStatement();
            rs =stmt.executeQuery(queryForNode.toString());
            while(rs.next()){
            	ConnectDevicesBean bean =new ConnectDevicesBean();
            	
            	bean.setEqipId(rs.getString("DVC_ID"));
            	bean.setDeviceType(rs.getString("DVC_TYP_ID"));
            	bean.setTrmNum(rs.getString("DVC_NUM"));
            	
            	list1.add(bean);
           	 
            }
            System.out.println(list1.size());
            stmt.close();
            rs.close();
        	
        }catch(Exception e) {
            e.printStackTrace();
        }
        }
        
        if(con != null){
        	
        	 try {
        		 for (ConnectDevicesBean bean:list1) {
        			 if(bean.getEqipId()!=null){
        				 
        				 StringBuilder queryForNode = new StringBuilder();
        	             	
        	             	queryForNode.append("select * from u90edm.hdwr_pkg_dvc_xref where dvc_id ="+bean.getEqipId().toString().trim());
        	             	
        	             	System.out.println(queryForNode.toString());
        	                 stmt = con.createStatement();
        	                 rs =stmt.executeQuery(queryForNode.toString());
        	                 
        	                 while(rs.next()){
        	                	 bean.setHdwrPkgID(""+rs.getInt("HDWR_PKG_ID"));
        	                 }
        	                 
        			 }
        			 
        			 list2.add(bean);                     
                     stmt.close();
                     rs.close();
        		 }
        		 
        		 System.out.println(list2.size());
        		 
             }catch(Exception e) {
                 e.printStackTrace();
             }
        	
        }
        
        
        
        if(con != null){
        	
       	 try {
       		 for (ConnectDevicesBean bean:list2) {
       			 if(bean.getHdwrPkgID()!=null){
       				 
       				 StringBuilder queryForNode = new StringBuilder();
       	             	
       	             	queryForNode.append("select * from u90edm.hdwr_pkg where id ="+bean.getHdwrPkgID().toString().trim());
       	             	
       	             	System.out.println(queryForNode.toString());
       	                 stmt = con.createStatement();
       	                 rs =stmt.executeQuery(queryForNode.toString());
       	                 
       	                 while(rs.next()){
       	                	 bean.setRegistration(""+rs.getInt("RGSTN_ST_ID"));
       	                	 bean.setLicenseTypeId(""+rs.getInt("LCNSE_TYP_ID"));
       	                 }
       	                 
       			 }
       			 
       			 list3.add(bean);                     
                 stmt.close();
                 rs.close();
       		 }
       		 
       		 System.out.println(list3.size());
       		 
            }catch(Exception e) {
                e.printStackTrace();
            }
       	
       }
        
        if(con != null){
        	
          	 try {
          		 for (ConnectDevicesBean bean:list3) {
          			 if(bean.getHdwrPkgID()!=null){
          				 
          				 StringBuilder queryForNode = new StringBuilder();
          	             	
          	             	queryForNode.append("select * from u90edm.mach_hdwr_pkg where hdwr_pkg_id ="+bean.getHdwrPkgID().toString().trim());
          	             	
          	             	System.out.println(queryForNode.toString());
          	                 stmt = con.createStatement();
          	                 rs =stmt.executeQuery(queryForNode.toString());
          	                 
          	                 while(rs.next()){
          	                	 bean.setTrmId(rs.getString("MACH_ID"));
          	                	 bean.setActivationDt(rs.getString("ACTV_ASSCN_IND"));
          	                 }
          	                 
          			 }
          			 
          			 list4.add(bean);                     
                    stmt.close();
                    rs.close();
          		 }
          		 
          		 System.out.println(list4.size());
          		 
               }catch(Exception e) {
                   e.printStackTrace();
               }
          	
          }
        
        if(con != null){
        	
         	 try {
         		 for (ConnectDevicesBean bean:list3) {
         			 if(bean.getTrmId()!=null){
         				 
         				 StringBuilder queryForNode = new StringBuilder();
         	             	
         	             	queryForNode.append("select*from u90edm.mach_info where mach_id ="+bean.getTrmId().toString().trim());
         	             	
         	             	System.out.println(queryForNode.toString());
         	                 stmt = con.createStatement();
         	                 rs =stmt.executeQuery(queryForNode.toString());
         	                 
         	                 while(rs.next()){
         	                	 bean.setPin(rs.getString("MACH_ID_NUM"));
         	                	 bean.setNodeId(""+rs.getInt("NODE_ID"));
         	                 }
         	                 
         			 }
         			 
         			 list5.add(bean);                     
                   stmt.close();
                   rs.close();
         		 }
         		 
         		 System.out.println(list5.size());
         		 
              }catch(Exception e) {
                  e.printStackTrace();
              }
         	
         }
        
        try{
            String FILE_PATH = "C:/Machine Data Aurora.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");

            Row row;
            int rowid = 0;
           
            row = sheet.createRow(rowid++);

            row.createCell(0).setCellValue("TRM_ID");
            row.createCell(1).setCellValue("TRM_NUM");
            row.createCell(2).setCellValue("EQIP_ID");
           
            row.createCell(3).setCellValue("DVC_TYP");
            row.createCell(4).setCellValue("RGSTN_DSC");
            
            row.createCell(5).setCellValue("LCNSE_TYP_ID");
            row.createCell(5).setCellValue("ACTV_ASSCN_IND");
            
            row.createCell(6).setCellValue("PIN");
                     
            for (ConnectDevicesBean bean:list3) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(bean.getEqipId());
                row.createCell(1).setCellValue(bean.getTrmNum());
                row.createCell(2).setCellValue(bean.getTrmId());
                
                row.createCell(3).setCellValue(bean.getDeviceType());                
                row.createCell(4).setCellValue(bean.getRegistration());
                
                row.createCell(5).setCellValue(bean.getLicenseTypeId());
                
                row.createCell(6).setCellValue(bean.getActivationDt());	 
                
                row.createCell(7).setCellValue(bean.getPin());
            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){
        	e.printStackTrace();
        }
	}

}
