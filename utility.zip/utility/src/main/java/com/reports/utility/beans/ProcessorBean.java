/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class ProcessorBean {
	
	 private String trmId;
	 private String trmNum;
	 private String deviceType;
	 private String activationDt;
	 private String pin;
	 private String licenseTypeId;
	 private String licenseExpTs;
	 private String hdwrCOActTs;
	 
	 private String verId;
	 private String verNm;
	 private String status;
	 private String instTs;
	 private String lstCnfTs;
	 private String modTs;
	 
	
	public String getTrmId() {
		return trmId;
	}
	public void setTrmId(String trmId) {
		this.trmId = trmId;
	}
	public String getTrmNum() {
		return trmNum;
	}
	public void setTrmNum(String trmNum) {
		this.trmNum = trmNum;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getActivationDt() {
		return activationDt;
	}
	public void setActivationDt(String activationDt) {
		this.activationDt = activationDt;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getLicenseTypeId() {
		return licenseTypeId;
	}
	public void setLicenseTypeId(String licenseTypeId) {
		this.licenseTypeId = licenseTypeId;
	}
	public String getLicenseExpTs() {
		return licenseExpTs;
	}
	public void setLicenseExpTs(String licenseExpTs) {
		this.licenseExpTs = licenseExpTs;
	}
	public String getHdwrCOActTs() {
		return hdwrCOActTs;
	}
	public void setHdwrCOActTs(String hdwrCOActTs) {
		this.hdwrCOActTs = hdwrCOActTs;
	}
	public String getVerId() {
		return verId;
	}
	public void setVerId(String verId) {
		this.verId = verId;
	}
	public String getVerNm() {
		return verNm;
	}
	public void setVerNm(String verNm) {
		this.verNm = verNm;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInstTs() {
		return instTs;
	}
	public void setInstTs(String instTs) {
		this.instTs = instTs;
	}
	public String getLstCnfTs() {
		return lstCnfTs;
	}
	public void setLstCnfTs(String lstCnfTs) {
		this.lstCnfTs = lstCnfTs;
	}
	public String getModTs() {
		return modTs;
	}
	public void setModTs(String modTs) {
		this.modTs = modTs;
	}
	 
}
