/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author Bk93287
 *
 */
public class GeofenceDtlbean {
	
	private String orgID;
	private String boundryID;
	private String boundryName;
	private String diaplay;
	private String machineId;
	private String pin;
	private String activeInd;
	private String actvStartTs;
	private String actvEndTs;
	private String lastModBy;
	private String lastModTs;
	private String geofenceId;
	private String boundryVerID;
	private String geofenceAreaTyp;
	private String centerLat;
	private String centerLong;
	private String bndVer1Lat;
	private String bndVer1Long;
	private String bndVer2Lat;
	private String bndVer2Long;
	private String bndVer3Lat;
	private String bndVer3Long;
	private String bndVer4Lat;
	private String bndVer4Long;
	/**
	 * @return the orgID
	 */
	public String getOrgID() {
		return orgID;
	}
	/**
	 * @param orgID the orgID to set
	 */
	public void setOrgID(String orgID) {
		this.orgID = orgID;
	}
	/**
	 * @return the boundryID
	 */
	public String getBoundryID() {
		return boundryID;
	}
	/**
	 * @param boundryID the boundryID to set
	 */
	public void setBoundryID(String boundryID) {
		this.boundryID = boundryID;
	}
	/**
	 * @return the boundryName
	 */
	public String getBoundryName() {
		return boundryName;
	}
	/**
	 * @param boundryName the boundryName to set
	 */
	public void setBoundryName(String boundryName) {
		this.boundryName = boundryName;
	}
	/**
	 * @return the diaplay
	 */
	public String getDiaplay() {
		return diaplay;
	}
	/**
	 * @param diaplay the diaplay to set
	 */
	public void setDiaplay(String diaplay) {
		this.diaplay = diaplay;
	}
	/**
	 * @return the machineId
	 */
	public String getMachineId() {
		return machineId;
	}
	/**
	 * @param machineId the machineId to set
	 */
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the activeInd
	 */
	public String getActiveInd() {
		return activeInd;
	}
	/**
	 * @param activeInd the activeInd to set
	 */
	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}
	/**
	 * @return the actvStartTs
	 */
	public String getActvStartTs() {
		return actvStartTs;
	}
	/**
	 * @param actvStartTs the actvStartTs to set
	 */
	public void setActvStartTs(String actvStartTs) {
		this.actvStartTs = actvStartTs;
	}
	/**
	 * @return the actvEndTs
	 */
	public String getActvEndTs() {
		return actvEndTs;
	}
	/**
	 * @param actvEndTs the actvEndTs to set
	 */
	public void setActvEndTs(String actvEndTs) {
		this.actvEndTs = actvEndTs;
	}
	/**
	 * @return the lastModBy
	 */
	public String getLastModBy() {
		return lastModBy;
	}
	/**
	 * @param lastModBy the lastModBy to set
	 */
	public void setLastModBy(String lastModBy) {
		this.lastModBy = lastModBy;
	}
	/**
	 * @return the lastModTs
	 */
	public String getLastModTs() {
		return lastModTs;
	}
	/**
	 * @param lastModTs the lastModTs to set
	 */
	public void setLastModTs(String lastModTs) {
		this.lastModTs = lastModTs;
	}
	/**
	 * @return the geofenceId
	 */
	public String getGeofenceId() {
		return geofenceId;
	}
	/**
	 * @param geofenceId the geofenceId to set
	 */
	public void setGeofenceId(String geofenceId) {
		this.geofenceId = geofenceId;
	}
	/**
	 * @return the boundryVerID
	 */
	public String getBoundryVerID() {
		return boundryVerID;
	}
	/**
	 * @param boundryVerID the boundryVerID to set
	 */
	public void setBoundryVerID(String boundryVerID) {
		this.boundryVerID = boundryVerID;
	}
	/**
	 * @return the geofenceAreaTyp
	 */
	public String getGeofenceAreaTyp() {
		return geofenceAreaTyp;
	}
	/**
	 * @param geofenceAreaTyp the geofenceAreaTyp to set
	 */
	public void setGeofenceAreaTyp(String geofenceAreaTyp) {
		this.geofenceAreaTyp = geofenceAreaTyp;
	}
	/**
	 * @return the centerLat
	 */
	public String getCenterLat() {
		return centerLat;
	}
	/**
	 * @param centerLat the centerLat to set
	 */
	public void setCenterLat(String centerLat) {
		this.centerLat = centerLat;
	}
	/**
	 * @return the centerLong
	 */
	public String getCenterLong() {
		return centerLong;
	}
	/**
	 * @param centerLong the centerLong to set
	 */
	public void setCenterLong(String centerLong) {
		this.centerLong = centerLong;
	}
	/**
	 * @return the bndVer1Lat
	 */
	public String getBndVer1Lat() {
		return bndVer1Lat;
	}
	/**
	 * @param bndVer1Lat the bndVer1Lat to set
	 */
	public void setBndVer1Lat(String bndVer1Lat) {
		this.bndVer1Lat = bndVer1Lat;
	}
	/**
	 * @return the bndVer1Long
	 */
	public String getBndVer1Long() {
		return bndVer1Long;
	}
	/**
	 * @param bndVer1Long the bndVer1Long to set
	 */
	public void setBndVer1Long(String bndVer1Long) {
		this.bndVer1Long = bndVer1Long;
	}
	/**
	 * @return the bndVer2Lat
	 */
	public String getBndVer2Lat() {
		return bndVer2Lat;
	}
	/**
	 * @param bndVer2Lat the bndVer2Lat to set
	 */
	public void setBndVer2Lat(String bndVer2Lat) {
		this.bndVer2Lat = bndVer2Lat;
	}
	/**
	 * @return the bndVer2Long
	 */
	public String getBndVer2Long() {
		return bndVer2Long;
	}
	/**
	 * @param bndVer2Long the bndVer2Long to set
	 */
	public void setBndVer2Long(String bndVer2Long) {
		this.bndVer2Long = bndVer2Long;
	}
	/**
	 * @return the bndVer3Lat
	 */
	public String getBndVer3Lat() {
		return bndVer3Lat;
	}
	/**
	 * @param bndVer3Lat the bndVer3Lat to set
	 */
	public void setBndVer3Lat(String bndVer3Lat) {
		this.bndVer3Lat = bndVer3Lat;
	}
	/**
	 * @return the bndVer3Long
	 */
	public String getBndVer3Long() {
		return bndVer3Long;
	}
	/**
	 * @param bndVer3Long the bndVer3Long to set
	 */
	public void setBndVer3Long(String bndVer3Long) {
		this.bndVer3Long = bndVer3Long;
	}
	/**
	 * @return the bndVer4Lat
	 */
	public String getBndVer4Lat() {
		return bndVer4Lat;
	}
	/**
	 * @param bndVer4Lat the bndVer4Lat to set
	 */
	public void setBndVer4Lat(String bndVer4Lat) {
		this.bndVer4Lat = bndVer4Lat;
	}
	/**
	 * @return the bndVer4Long
	 */
	public String getBndVer4Long() {
		return bndVer4Long;
	}
	/**
	 * @param bndVer4Long the bndVer4Long to set
	 */
	public void setBndVer4Long(String bndVer4Long) {
		this.bndVer4Long = bndVer4Long;
	}

	
}
