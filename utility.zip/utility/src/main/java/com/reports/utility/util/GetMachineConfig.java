/**
 * 
 */
package com.reports.utility.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.ConnectDevicesBean;


/**
 * @author BK93287
 *
 */
public class GetMachineConfig {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection con = null;
		Connection con1 = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://dm-aurora-aws-1.c0cixceidvey.us-east-1.rds.amazonaws.com:3306/u90edm", "BK93287", "BK93287PROD");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        List<ConnectDevicesBean> list1 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list2 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list3 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list4 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list5 = new ArrayList<ConnectDevicesBean>();
        
        if(con != null){
        	
            try {
            	StringBuilder queryForNode = new StringBuilder();
            	
            	queryForNode.append("select * from u90edm.mach_info where mach_id_num in ");
            	queryForNode.append("('1RW6175RCGA024190','1RW6195RVGD025318','1RW6175RLGT025140','1RW6215RTGD025410','1RW6175RJGA025788','1RW6175REGA024780','1RW6215REFD024057','1RW6175RCGT024307','1RW6175RHGA025393','1RW6215RLGD026051','1RW6175REGD026124','1RW6175RHGD024386','1RW6175RCGA025364','1RW6175RHFD024077','1RW6215RVGT024996','1RW6175REGA024567','1RW6175RAGT025136','1RW6175RHGA025054','1RW6175RCGA025677','1RW6215RCGR025528','1RW6175RCFD024008','1RW6175RKGA024171','1RW6195RCGD025343','1RW6175RCGD025063','1RW6215REGT024440','1RW6195RCGD024264','1RW6215REGT024633','1RW6175RKGR025337','1RW6195RTGD024923','1RW6175REGD024082','1RW6195RCGD024698','1RW6175RCGD026044','1RW6175RHGD025098','1RW6175RPGD024135','1RW6175RTGA024569','1RW6195RCGD024099','1RW6175RHGT024636','1RW6175RLFD024028','1RW6175RVGA024353','1RW6215RCGD025874','1RW6175RHGA024163','1RW6175RHGD024193','1RW6195RTGD024677','1RW6175RKGA025370','1RW6215RVGD026130','1RW6175RCGD024382','1RW6175REGA024830','1RW6175RCGA024481','1RW6175RJGA024530','1RW6175RTGD025171','1RW6195RTGD025683','1RW6175RJGD024493','1RW6175RPGA024346','1RW6175RVGA024708','1RW6175RLGA024520','1RW6175RLGD024371','1RW6175RJGT024614','1RW6175RKGD026078','1RW6175RVGD024447','1RW6175RHGD024145','1RW6215RHGD025418','1RW6215RHGD025418','1RW6175RLGT024165','1RW6195REGD025096','1RW6195RKGD024715','1RW6215RCGD026093','1RW6175RHFD024001','1RW6175REGA024150','1RW6175RVGA024160','1RW6175REGD025524','1RW6175RCGT024431','1RW6175RJGA024463','1RW6175REGD024115','1RW6175RPGA025366','1RW6175RJGD024753','1RW6175RTGD025008','1RW6175RJGD025210','1RW6195REGD024482','1RW6195REGD025941','1RW6195RHGT024518','1RW6195RPGD026074','1RW6195RTGD025182','1RW6175RPGA024136','1RW6195RAGT024550','1RW6195RLGD025189','1RW6175RPGA024718','1RW6195REGA025441','1RW6175RLGA024632','1RW6175REGA026142','1RW6175RKGD024878','1RW6195RLGD025404','1RW6175RAGD024109','1RW6175RJGD025207','1RW6175RTGD025932','1RW6215RHGR024188','1RW6175RLGD025939','1RW6215RCGA024595','1RW6195RAGA024544','1RW6175REGD025104','1RW6175RKGD024184','1RW6175RHGD024131','1RW6175RCGD024379','1RW6195RLGD025385','1RW6215RCGD025437','1RW6215RPGD026137','1RW6175RJGD026048','1RW6175RLGA025165','1RW6175RKGD024153','1RW6175RCGD025600','1RW6175RJGA024124','1RW6175RTGR024833','1RW6195REGD025972','1RW6175RLGA024811','1RW6195RHGD024576','1RW6175RLGD026198','1RW6175RTGA025382','1RW6215RTGA024419','1RW6175RHGA025376','1RW6175RPGA025190','1RW6175RAGD025194','1RW6175RHGA024602','1RW6175RAGD025583','1RW6175RPGD024796','1RW6175RHGA024468','1RW6175RAGA025374','1RW6175RPGD024426','1RW6175RVGD024416','1RW6175RAGD025180','1RW6175RVGD024111','1RW6215RAGD025433','1RW6195RCGD025110','1RW6195RCGD025312','1RW6175RHGD024792','1RW6215RCGA025432','1RW6175RJGA025399','1RW6175RLGT024487','1RW6175RAGA025388','1RW6175RKGA025126','1RW6175RTGT024317','1RW6195RKGA024795','1RW6195RAGR024142','1RW6195RJGT024737','1RW6175RCGT024977','1RW6175REGD025166','1RW6215RAGT024448','1RW6175RJGA024169','1RW6195RVGT024725','1RW6175RCGA025372','1RW6195RLGD025242','1RW6175RCGD024195','1RW6175RHGD024341','1RW6175RTGA024605','1RW6175RCGA025784','1RW6195RLGD024284','1RW6175RAGD025759','1RW6175RPGT024612','1RW6175RTGA025284','1RW6175RPGD025589','1RW6175RVGT024552','1RW6195RCGD025334','1RW6175RAGD024966','1RW6175RKGA025742','1RW6195RVGT025034','1RW6215RPGD025392','1RW6195RHGD025369','1RW6195RPGR024957','1RW6175REGD025538','1RW6175RHGA025068','1RW6195RTGA024101','1RW6175RVGA024272','1RW6175REGD025345','1RW6215REGD025422','1RW6175RCGA024156','1RW6175RVGD024545','1RW6195RCGD025293','1RW6175RCGR024877','1RW6195REGD024692','1RW6195RLGD024723','1RW6175RHGA025362','1RW6215RCGD024294','1RW6215RCGT024617','1RW6215RKGT024945','1RW6175RHGD024825','1RW6195RCGD025205','1RW6175RCGA025817','1RW6195REGD025387','1RW6215RAGD026159','1RW6195RJGD024389','1RW6175RCGD024441','1RW6175RVGA026054','1RW6175RPFD024070','1RW6175RTGT024429','1RW6175RCGA025159','1RW6175RJGT024435','1RW6195RAGA025192','1RW6195RCGD024913','1RW6175RHGD024369','1RW6175RTGR025352','1RW6175RJGD025577','1RW6195REGD025373','1RW6175RCGD024259','1RW6175RCGA025834','1RW6195RPGT024203','1RW6175RHGA024180','1RW6175RAGA024161','1RW6175RPGD024314','1RW6175REGD025863','1RW6195RCGT025624','1RW6175RJGD024901','1RW6175RKFD024071','1RW6175RHGD024551','1RW6175RKGD026095','1RW6175RCGA024450','1RW6195RTGD025540','1RW6175RLGT024411','1RW6175RCFA024049','1RW6175RJGT024998','1RW6175RHGD025196','1RW6175RVGD024223','1RW6175RCGD025449','1RW6175RLGA025764','1RW6175RCGA025395','1RW6215RLGD024655','1RW6195RKGD024701','1RW6195RCGD025253','1RW6195RKFD024065','1RW6195RKGD024391','1RW6175RCGD025668','1RW6195RTGT024748','1RW6175RPGT026098','1RW6175RCFA024012','1RW6175RVGD026103','1RW6175RVGT024423','1RW6195RHGD024089','1RW6195RJFD024021','1RW6175RPGT024593','1RW6195RHGD024836','1RW6175REGT025562','1RW6175RLGT024408','1RW6215RVGT024819','1RW6175RCGA025378','1RW6175RJGT024404','1RW6175REGT024394','1RW6175REGD024972','1RW6175REGD024535','1RW6175RVGD025579','1RW6195RCGA024797','1RW6175RTGD025221','1RW6175RCGD025046','1RW6195RHGD024125','1RW6195RLGT024758','1RW6195RVGD024637','1RW6175RHGT024586','1RW6175RJGA024091','1RW6175RPFD024005','1RW6215RAGD025853','1RW6175RCGD024679','1RW6175RCGD024950','1RW6215RCGR024167','1RW6175RCGD025086','1RW6175RLGA026199','1RW6215RCGD024733','1RW6175RCGT024338','1RW6175REGA024472','1RW6175RHGT024510','1RW6175RTGA025768','1RW6195RJGD024635','1RW6175RAGA024340','1RW6175RCGD024956','1RW6215RJGT024994','1RW6195RCGD025536','1RW6175RLGD024418','1RW6175RLGT024960','1RW6215RVGD024717','1RW6175RCGA025534','1RW6195RTFD024080','1RW6175REGD024907',");
            	queryForNode.append("'1RW6195RTGD024405','1RW6175RJGR025145','1RW6175RCGA024392') order by dtl_mach_cd asc");
            	
            	System.out.println(queryForNode.toString());
                stmt = con.createStatement();
                rs =stmt.executeQuery(queryForNode.toString());
                while(rs.next()){
                	ConnectDevicesBean bean =new ConnectDevicesBean();
                	
                	bean.setEqipId(rs.getString("MACH_ID"));
                	bean.setDeviceType(rs.getString("MACH_ID_NUM"));
                	bean.setTrmNum(rs.getString("DTL_MACH_CD"));
                	
                	list1.add(bean);
               	 
                }
                System.out.println(list1.size());
                stmt.close();
                rs.close();
                con.close();
            	
            }catch(Exception e) {
                e.printStackTrace();
            }
          }
        
        
        try {
            Class.forName("com.ibm.db2.jcc.DB2Driver");
            try {
            	con1 = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "BK93287", "jdlink24");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }

        
        if(con1 != null){
        	try {
        		for (ConnectDevicesBean bean:list1) {
        			if(bean.getTrmNum()!=null){
        				
        				 StringBuilder queryForNode = new StringBuilder();
	    				 queryForNode.append("SELECT * FROM U90ECEP.CONFIG_MDL_RNG WHERE DTL_MACH_CD in ('"+bean.getTrmNum().toString().trim());
                         queryForNode.append("') WITH UR FOR READ ONLY;");
                         
                         System.out.println(queryForNode.toString());
	                     stmt = con1.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 bean.setRegistration(""+rs.getInt("CONFIG_MDL_STRNG_ID"));
	                     }
        				
        			}
        			 list2.add(bean);                     
                     stmt.close();
                     rs.close();
        		}
        	}catch(Exception e) {
                e.printStackTrace();
            }
        }
        
        if (list2.size() > 0) {
        	  Collections.sort(list2, new Comparator<ConnectDevicesBean>() {
        	      @Override
        	      public int compare(final ConnectDevicesBean object1, final ConnectDevicesBean object2) {
        	          return object1.getRegistration().compareTo(object2.getRegistration());
        	      }
        	  });
        	}
        
        try{
            String FILE_PATH = "C:/config.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");

            Row row;
            int rowid = 0;
           
            row = sheet.createRow(rowid++);

            row.createCell(0).setCellValue("MACH_ID");
            row.createCell(1).setCellValue("PIN");
            row.createCell(2).setCellValue("DTL_MACH_CD");
            row.createCell(3).setCellValue("MDL_STRNG_ID");
          
                     
            for (ConnectDevicesBean bean:list2) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(bean.getEqipId());
                row.createCell(1).setCellValue(bean.getDeviceType());
                row.createCell(2).setCellValue(bean.getTrmNum());
                row.createCell(3).setCellValue(bean.getRegistration());
               
            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){
        	e.printStackTrace();
        }
        
	}

}
