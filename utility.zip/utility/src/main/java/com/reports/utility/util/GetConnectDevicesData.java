/**
 * 
 */
package com.reports.utility.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.ConnectDevicesBean;




/**
 * @author BK93287
 *
 */
public class GetConnectDevicesData {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.ibm.db2.jcc.DB2Driver");
            try {
                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        List<ConnectDevicesBean> list1 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list2 = new ArrayList<ConnectDevicesBean>();
        List<ConnectDevicesBean> list3 = new ArrayList<ConnectDevicesBean>();

        if(con != null){
            try {
            	
            	StringBuilder queryForNode = new StringBuilder();
            	
            	queryForNode.append("SELECT * FROM U90JLKP.NN_TRM_DTL WHERE PIN LIKE '1WJ%' AND DVC_TYP LIKE '%GSix_4600_Display%'");
            	queryForNode.append(" ORDER BY ACTVN_DT DESC WITH UR FOR READ ONLY;");
            	System.out.println(queryForNode.toString());
                stmt = con.createStatement();
                rs =stmt.executeQuery(queryForNode.toString());
                while(rs.next()){
                	ConnectDevicesBean bean =new ConnectDevicesBean();
                	
                	bean.setTrmId(rs.getString("TRM_ID"));
                	bean.setTrmNum(rs.getString("TRM_NUM"));
                	bean.setEqipId(rs.getString("EQIP_ID"));
                	bean.setRegistration(rs.getString("RGSTN_DSC"));
                	bean.setCoId(rs.getString("CO_ID"));
                	bean.setDeviceType(rs.getString("DVC_TYP"));
                	bean.setActivationDt(rs.getString("ACTVN_DT"));
                	bean.setPin(rs.getString("PIN"));
                	bean.setLicenseTypeId(rs.getString("LCNSE_TYP_ID"));
                	bean.setLicenseExpTs(rs.getString("LCNSE_EXPR_TS"));
                	bean.setHdwrCOActTs(rs.getString("HDWR_CO_ACTVN_TS"));
                	
                	list1.add(bean);
               	 
                }
                System.out.println(list1.size());
                stmt.close();
                rs.close();
            	
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
        

        if(con != null){
            try {
            	for (ConnectDevicesBean bean:list1) {
	    			 if(bean.getEqipId()!=null){
	    				 StringBuilder queryForNode = new StringBuilder();
	    				 queryForNode.append("SELECT DISTINCT(MHF.MACH_ID_NUM),MHF.MACH_ID,MHF.MACH_NM,MHF.NODE_ID FROM U90EDMP.MACH_INFO MHF WHERE MHF.MACH_ID = '"+bean.getEqipId().toString().trim());
                         queryForNode.append("' WITH UR FOR READ ONLY;");
                         
                         System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 bean.setNodeId(""+rs.getInt("NODE_ID"));
	                     }
	    			 }
	    			 
	    			 list2.add(bean);                     
                     stmt.close();
                     rs.close();
            	}
            	System.out.println(list2.size());
            	
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
        

//        if(con != null){
//            try {
//            	for (ConnectDevicesBean bean:list1) {
//	    			 if(bean.getNodeId()!=null){
//	    				 
//	    				 int nodeId=Integer.parseInt(bean.getNodeId());
//	    				 StringBuilder queryForNode = new StringBuilder();
//	    				 
//	    				 if(nodeId<=10){	    					 
//	    					 int actnode=nodeId-1;
//	    					 queryForNode.append("SELECT * FROM J9000"+actnode+"P");
//	    					 queryForNode.append(".EQIP_CALL_IN_INFO WHERE MACH_ID = "+bean.getEqipId().toString().trim());
//	    					 queryForNode.append(" ORDER BY CPTR_TS DESC FETCH FIRST ROWS ONLY;");
//	    				 }else if(nodeId>=11){
//	    					 int actnode=nodeId-1;
//	    					 queryForNode.append("SELECT * FROM J900"+actnode+"P");
//	    					 queryForNode.append(".EQIP_CALL_IN_INFO WHERE MACH_ID = "+bean.getEqipId().toString().trim());
//	    					 queryForNode.append(" ORDER BY CPTR_TS DESC FETCH FIRST ROWS ONLY;");
//	    				 }
//	    				 System.out.println(queryForNode.toString());
//	                     stmt = con.createStatement();
//	                     rs =stmt.executeQuery(queryForNode.toString());
//	                     
//	                     if (rs.next()) {
//	                    	 
//	                    	bean.setLastCallinTS(rs.getString("CPTR_TS"));
//	                    	
//	                     } 
//	    			 }
//	    			 
//	    			 list3.add(bean);                     
//                     stmt.close();
//                     rs.close();
//            	}
//            	
//            	System.out.println(list3.size());
//            	
//            }catch(Exception e) {
//                e.printStackTrace();
//            }
//        }
        
        try{
            String FILE_PATH = "C:/Machine Data 1.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");

            Row row;
            int rowid = 0;
           
            row = sheet.createRow(rowid++);

            row.createCell(0).setCellValue("TRM_ID");
            row.createCell(1).setCellValue("TRM_NUM");
            row.createCell(2).setCellValue("EQIP_ID");
            row.createCell(3).setCellValue("RGSTN_DSC");
            row.createCell(4).setCellValue("CO_ID");
            row.createCell(5).setCellValue("DVC_TYP");
            row.createCell(6).setCellValue("ACTVN_DT");
            
            row.createCell(7).setCellValue("PIN");
            row.createCell(8).setCellValue("LCNSE_TYP_ID");
            row.createCell(9).setCellValue("LCNSE_EXPR_TS");
            row.createCell(10).setCellValue("HDWR_CO_ACTVN_TS");
          //  row.createCell(11).setCellValue("LAST_CALLIN_TS");
                     
            for (ConnectDevicesBean bean:list2) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(bean.getTrmId());
                row.createCell(1).setCellValue(bean.getTrmNum());
                row.createCell(2).setCellValue(bean.getEqipId());
                row.createCell(3).setCellValue(bean.getRegistration());
                row.createCell(4).setCellValue(bean.getCoId());
                row.createCell(5).setCellValue(bean.getDeviceType());
                row.createCell(6).setCellValue(bean.getActivationDt());	 
                
                row.createCell(7).setCellValue(bean.getPin());
                row.createCell(8).setCellValue(bean.getLicenseTypeId());
                row.createCell(9).setCellValue(bean.getLicenseExpTs());
                row.createCell(10).setCellValue(bean.getHdwrCOActTs());
               // row.createCell(11).setCellValue(bean.getLastCallinTS());
            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){
        	e.printStackTrace();
        }
        
        
	}

}
