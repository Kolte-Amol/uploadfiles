/**
 * 
 */
package com.reports.utility.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.MaintainceBean;


/**
 * @author BK93287
 *
 */
public class GetUserData {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		 Connection con = null;
	     Statement stmt = null;
	     ResultSet rs = null;
	     
	     List<MaintainceBean> list1=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list2=new ArrayList<MaintainceBean>();
	   
	
	     
	     
	     try {
	            Class.forName("com.ibm.db2.jcc.DB2Driver");
	            try {
	                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
	                System.out.println("Connection established with the Database. ");
	            } catch(SQLException e) {
	                e.printStackTrace();
	            }
	        } catch(ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        
	        try{
	        	String FilePath = "C:/178711.xlsx";
	            FileInputStream fs = new FileInputStream(FilePath);
	            Workbook workbook =  new XSSFWorkbook(fs);
	            Sheet sheet = workbook.getSheetAt(0);
	            int totalNoOfRows = 469;
	            int totalNoOfCols = 7;

	            for (int r = 0; r < totalNoOfRows; r++) {
	                Row row=sheet.getRow(r);
	                MaintainceBean mb= new MaintainceBean();
	                for (int col = 0; col < totalNoOfCols; col++) {
	                    Cell cell=row.getCell(col);
	                    if(col==0){
	                    	if(cell!=null){
	                    		 mb.setMachId(cell.getStringCellValue());
	                    	}	                       
	                    }else if(col==1){
	                        if(cell!=null){
	                            mb.setPin(cell.getStringCellValue());
	                        }
	                    }else if(col==2){
	                    	if(cell!=null){
	                    		 mb.setMachineNM(cell.getStringCellValue());
	                    	}	  
	                    }else if(col==3){
	                        if(cell!=null){
	                            mb.setAccountNm(cell.getStringCellValue());
	                        }
	                    }else if(col==4){
	                        if(cell!=null){
	                            mb.setEquipGrpNm(cell.getStringCellValue());
	                        }

	                    }else if(col==5){
	                        if(cell!=null){
	                            mb.setEngineHrs(cell.getStringCellValue());
	                        }

	                    }else if(col==6){
	                        if(cell!=null){
	                            mb.setLastUpdatedTs(cell.getStringCellValue());
	                        }
	                    }
	                }
	                list1.add(mb);
	            }
	            System.out.println(list1.size());
	        }catch (IOException e){
	            e.printStackTrace();
	        }
//----------------------------------------------------------------------------------------------
	        
	        if(con != null) {
	        	System.out.println("1");
		    	 try{
		    		 for (MaintainceBean dm:list1) {
		    			 System.out.println("2"+dm.getMachId());
		    			 String machID=""+dm.getMachId();
		    			 if(!(machID.equalsIgnoreCase("null"))){
		    				 if(!(machID.isEmpty())){
		    					 System.out.println("3"+machID);
			    				 StringBuilder queryForNode = new StringBuilder();
			    				 queryForNode.append("SELECT DISTINCT(CO_ID) FROM U90JLKP.NN_TRM_DTL WHERE EQIP_ID = '" + machID.toString().trim());
	                             queryForNode.append("' WITH UR FOR READ ONLY;");
				    			 
				    			 System.out.println(queryForNode.toString());
			                     stmt = con.createStatement();
			                     rs =stmt.executeQuery(queryForNode.toString());
			                     
			                     if (rs.next()) {
			                    	 dm.setAccountId(""+rs.getInt("CO_ID"));		                    	
			                     }
			                     stmt.close();
			                     rs.close();
		    				 }
		    				 
		    			 }
		    			 
	                     list2.add(dm);
	                     
	                     
		    		 }
		    		 System.out.println(list2.size());
		    		 
		    	 }catch(Exception e) {
	                 e.printStackTrace();
	             }
		    	 
		     }
		     
		//------------------------------------------------------------------------------------------
	        
	        try{
	            String FILE_PATH = "C:/Machine Data.xlsx";
	            Workbook workbook = new XSSFWorkbook();

	            Sheet sheet = workbook.createSheet("report");

	            Row row;
	            int rowid = 0;
	           
	            row = sheet.createRow(rowid++);

	            row.createCell(0).setCellValue("MACH_ID");
	            row.createCell(1).setCellValue("PIN");
	            row.createCell(2).setCellValue("MACHINE NAME");
	            row.createCell(3).setCellValue("THIRD PARTY DEALER");
	            row.createCell(4).setCellValue("EQUIPMENT GROUPS");
	            row.createCell(5).setCellValue("ENGINE HOURS");
	            row.createCell(6).setCellValue("LAST UPDATED TIME STAMP");
	            row.createCell(7).setCellValue("ORG_ID");
	           
	            for (MaintainceBean dm:list2) {
	                row = sheet.createRow(rowid++);
	                row.createCell(0).setCellValue(dm.getMachId());
	                row.createCell(1).setCellValue(dm.getPin());
	                row.createCell(2).setCellValue(dm.getMachineNM());
	                row.createCell(3).setCellValue(dm.getAccountNm());
	                row.createCell(4).setCellValue(dm.getEquipGrpNm());
	                row.createCell(5).setCellValue(dm.getEngineHrs());
	                row.createCell(6).setCellValue(dm.getLastUpdatedTs());	
	                row.createCell(7).setCellValue(dm.getAccountId());
	            }

	            try {
	                FileOutputStream fos = new FileOutputStream(FILE_PATH);
	                workbook.write(fos);
	                fos.close();

	                System.out.println(FILE_PATH + " is successfully written");
	            } catch (FileNotFoundException e) {
	                e.printStackTrace();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }

	        }catch (Exception e){
	        	e.printStackTrace();
	        }    
	}

}
