/**
 * 
 */
package com.reports.utility.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.xml.bind.JAXBElement;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.deere.api.axiom.generated.v3.Collection;
import com.deere.api.axiom.generated.v3.Resource;
import com.deere.api.axiom.generated.v3.Terminal;
import com.deere.api.axiom.generated.v3.Machine;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.reports.utility.beans.ConfigBean;
import com.reports.utility.beans.IccIdBean;
import com.reports.utility.beans.MachineDTO;


/**
 * @author BK93287
 *
 */
public class AssetManagerDump {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		AssetManagerDump assetManagerDump = new AssetManagerDump();
		
	//	List<String> test = assetManagerDump.readExcel(assetManagerDump);
		
	//	List<String> st =assetManagerDump.readExcel(assetManagerDump);
		
		List<MachineDTO> machine = assetManagerDump.getMachineData(
				assetManagerDump.getAllMachineFromDM(assetManagerDump.getConnectionForAuroraDB()), 
				assetManagerDump, 
				assetManagerDump.getConnectionForAuroraDB());

		List<List<MachineDTO>> subSets = Lists.partition(machine, 50000);
		
		assetManagerDump.generateExcel(subSets);

	}
//--------------------------------- Connecting to Database --------------------------------------------------	
	
	public Connection getConnectionForAuroraDB(){
		Connection con = null;
		try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://dm-aurora-aws-1.c0cixceidvey.us-east-1.rds.amazonaws.com:3306/u90edm", "BK93287", "BK93287PROD");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
		return con;		
	}
	
//------------------------------------------------ Get all machines from dm db ----------------------------------------------	
	public List<String> getAllMachineFromDM(Connection con){
		
		List<String> list1 = new ArrayList<String>();
//		List<String> list2 = new ArrayList<String>();
//		List<String> list3 = new ArrayList<String>();
//		List<String> list4 = new ArrayList<String>();
//		
//		String FilePath = "C:/machineids_1.xlsx";
//		String FilePath1 = "C:/machineids_2.xlsx";
//		String FilePath2 = "C:/machineids_3.xlsx";
//		String FilePath3 = "C:/machineids_4.xlsx";
//		
//		list1 = assetManagerDump.loopExcel(list1, FilePath);
//		list2 = assetManagerDump.loopExcel(list1, FilePath1);
//		list3 = assetManagerDump.loopExcel(list2, FilePath2);
//		list4 = assetManagerDump.loopExcel(list3, FilePath3);
		
		 if(con != null){
			 
			 try{
				 
				 		StringBuilder queryForNode = new StringBuilder();
				 		
				 		queryForNode.append("SELECT MACH_ID FROM U90EDM.MACH_INFO");
				 		System.out.println(queryForNode.toString());
		            	Statement stmt = con.createStatement();
		            	ResultSet rs =stmt.executeQuery(queryForNode.toString());
		            	
		            	 while(rs.next()){
		            		 
		            		 String st = rs.getString("MACH_ID");
		            		 if(!st.equalsIgnoreCase("97598")){
		            			 list1.add(rs.getString("MACH_ID"));
		            		 }
		            		 
		            	 }
		            	 
		            	 
		            	 System.out.println(list1.size());
			             stmt.close();
			             rs.close(); 
				 
					
				}catch(Exception e){
					e.printStackTrace();
				}
			 
		 }		
		
		 Collections.sort(list1);
		 
		List<List<String>> partition = Lists.partition(list1,1000);
		List<String> commaSeperatedMachineIds = new ArrayList<String>();

		partition.forEach(partitionList -> {
			commaSeperatedMachineIds.add(Joiner.on(',').join(partitionList));
			});

		return commaSeperatedMachineIds;
      
	}

//----------------------------------- looping Excel (not being used anymore) -------------------------------------------	
	
	public List<String> loopExcel(List<String> list, String FilePath){
		
			try {
			
			
					FileInputStream fs = new FileInputStream(FilePath);
					Workbook workbook =  new XSSFWorkbook(fs);
					Sheet sheet = workbook.getSheetAt(0);
            
					int totalNoOfRows;   
					
					if(FilePath.equalsIgnoreCase("C:/machineids_4.xlsx")){
						totalNoOfRows = 100664;
					}else{
						totalNoOfRows = 100000;
					}
            
					for (int r = 0; r < totalNoOfRows; r++) {
						Row row=sheet.getRow(r);
						Cell cell=row.getCell(0);
						DataFormatter formatter = new DataFormatter();
                        String cellValue = formatter.formatCellValue(cell);                                         
						list.add(""+cellValue.toString().trim());
					}
            
			} catch (IOException e) {			
			e.printStackTrace();
			}
		
		System.out.println(list.size());
		return list;
	}
	
	

	public List<MachineDTO> getMachineData(List<String> list, AssetManagerDump assetManagerDump, Connection connection){

		List<MachineDTO> machineList = new ArrayList<MachineDTO>();	
//		int i=0;
//		for (String string:list){			
			
//		}
//		if(i>397){
	
		list.forEach(string ->{	
				
							final String uri = "https://terminalws.deere.com/TerminalComponent/api/equipments/machines?id="+
							string.trim()+"&embed=machineAssociatedDevices";
							StringBuilder deviceids = new StringBuilder();
				
							List<MachineDTO> machines = new ArrayList();							
							System.out.println(""+uri);
						    RestTemplate restTemplate = new RestTemplate();
					        ResponseEntity<Collection> result=null;
							try {
								result = restTemplate.exchange(uri, HttpMethod.GET, 
										new HttpEntity<Object>(assetManagerDump.createHeaders()), Collection.class);
							} catch (RestClientException e) {
								// TODO Auto-generated catch block
								System.out.println("@@@@@@@@"+uri);
								e.printStackTrace();								
							}
					        
					        Collection col = result.getBody();
					        List<JAXBElement<? extends Resource>> resources = col.getResources();
					        
					        resources.forEach(resource ->{
					        	Machine value = (Machine) resource.getValue();
					        	MachineDTO machine = new MachineDTO();
					        	
					        	machine.setMachineId(""+value.getId());
					        	machine.setPin(""+value.getVin());
					        	if(value.getMake()!=null){
					        		machine.setMake(""+value.getMake().getName());
					        	}
					        	if(value.getModel()!=null){
					        		machine.setModel(""+value.getModel().getName());
					        	}	
					        	
					        	if(value.getCategory()!=null){
					        		machine.setType(""+value.getCategory().getName());
					        	}
					        	
					        	
					        	List<Terminal> terminal = value.getTerminals().getTerminals();
					        	
					        	terminal.forEach(serialNumber ->{
					        		if(serialNumber!=null){
					        			if(serialNumber.getRegistrationStatus()!=null){
					        				if(serialNumber.getRegistrationStatus().equalsIgnoreCase("Registered") || 
							        				serialNumber.getRegistrationStatus().equalsIgnoreCase("Pending Registration")){
							        			machine.setDeviceId(""+serialNumber.getId());
							        			machine.setSerialNumber(""+serialNumber.getSerialNumber());
								        		deviceids.append(""+serialNumber.getId()+",");
							        		}
					        			}
					        		}
					        		
					        	});
					        	
					        	machines.add(machine);
					        });	   				
					            
					        if(deviceids == null || deviceids.toString().equals("")){					        	 
							        machines.forEach(machinel ->{
							        	machineList.add(machinel);
							        });
					        	
					        }else{
					        	// System.out.println(""+deviceids);
							        List<MachineDTO> tempList =  assetManagerDump.mergeList(machines, 
							        		assetManagerDump.getCurrentConfig(deviceids.substring(0, (deviceids.length()-1)).toString().trim(), connection));
							        tempList.forEach(machinel ->{
							        	machineList.add(machinel);
							        });
					        	
					        }
					       
		//}		        
//					        i++;
//							System.out.println(""+i);
		});
		
		System.out.println(""+machineList.size());
		return machineList;
	}
		
	private List<ConfigBean> getCurrentConfig(String string, Connection con) {
		
		List<ConfigBean> configs = new ArrayList();
		 if(con != null){
			 try {
				 
				 StringBuilder queryForNode = new StringBuilder();
				 queryForNode.append("SELECT TF.DVC_ID, TF.DVC_NUM, TF.CNFG_VER_ID, VER.VER_NM FROM U90EDM.TRM_INFO TF ");
				 queryForNode.append("LEFT JOIN U90EDM.VERSION VER ON VER.VER_ID = TF.CNFG_VER_ID WHERE TF.DVC_ID IN ("+string.trim()+")");
				 
				 Statement stmt = con.createStatement();
	            	ResultSet rs =stmt.executeQuery(queryForNode.toString());
	                while(rs.next()){
	                	ConfigBean bean = new ConfigBean();
	                	bean.setDvcid(""+rs.getString("DVC_ID"));
	                	bean.setTrmNum(""+rs.getString("DVC_NUM"));
	                	bean.setConfigGUID(""+rs.getString("VER_NM"));
	                	
	                	configs.add(bean);
	                }
	                
	                stmt.close();
	                rs.close(); 
	                
			 }catch(Exception e){
				 e.printStackTrace();
			 }
		 }
		
		return configs;
		
	}
	
	public List<MachineDTO> mergeList(List<MachineDTO> machineList, List<ConfigBean> configs){
		List<MachineDTO> machines = new ArrayList();	
		
		machineList.forEach(machine ->{
			if(machine.getDeviceId()!=null){
				for(ConfigBean config : configs){
					if(machine.getDeviceId().equalsIgnoreCase(config.getDvcid())){
						machine.setCurrentConfig(config.getConfigGUID());
					}
				}
			}			
			machines.add(machine);
		});
		
		return machines;
	}

	@SuppressWarnings("serial")
	public HttpHeaders createHeaders(){
		   return new HttpHeaders() {{
		         String auth = "BK93287" + ":" + "jdlink24";
		         byte[] encodedAuth = Base64.encodeBase64( 
		            auth.getBytes(Charset.forName("US-ASCII")) );
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
	}
	
	
	private void generateExcel(List<List<MachineDTO>> subSets) {
		
		int i=1;
		for (List<MachineDTO> machineList:subSets) {
			try{
	            String FILE_PATH = "C:/Iccid_report"+i+".xlsx";
	            i++;
	            System.out.println(""+i+"@@@"+FILE_PATH);
	            Workbook workbook = new SXSSFWorkbook();

	            Sheet sheet = workbook.createSheet("report");
	            //Create row object
	            Row row;
	            int rowid = 0;
	            row = sheet.createRow(rowid++);

	            row.createCell(0).setCellValue("MACH_ID");
	            row.createCell(1).setCellValue("PIN");
	            row.createCell(2).setCellValue("MAKE");
	            row.createCell(3).setCellValue("TYPE");
	            row.createCell(4).setCellValue("MODEL");
	            row.createCell(5).setCellValue("DVC_ID");
	            
	            row.createCell(6).setCellValue("SERIAL_NUMBER");
	            row.createCell(7).setCellValue("CURRENT_CONFIG");
	            
	            for (MachineDTO bean:machineList) {
	                row = sheet.createRow(rowid++);
	                row.createCell(0).setCellValue(bean.getMachineId());
	                row.createCell(1).setCellValue(bean.getPin());
	                row.createCell(2).setCellValue(bean.getMake());
	                row.createCell(3).setCellValue(bean.getType());
	                row.createCell(4).setCellValue(bean.getModel());
	                row.createCell(5).setCellValue(bean.getDeviceId());
	                
	                row.createCell(6).setCellValue(bean.getSerialNumber());
	                row.createCell(7).setCellValue(bean.getCurrentConfig());
	            }

	            try {
	                FileOutputStream fos = new FileOutputStream(FILE_PATH);
	                workbook.write(fos);
	                fos.close();

	                System.out.println(FILE_PATH + " is successfully written");
	            } catch (FileNotFoundException e) {
	                e.printStackTrace();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	            
	        }catch (Exception e){

	        }
		}
	}
	
	
}
