package com.reports.utility.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.MaintainceBean;


/**
 * @author BK93287
 *
 */
public class GetMaintainceData2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 Connection con = null;
	     Statement stmt = null;
	     ResultSet rs = null;
	     
	     List<MaintainceBean> list1=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list2=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list3=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list4=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list5=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list6=new ArrayList<MaintainceBean>();
	     List<MaintainceBean> list7=new ArrayList<MaintainceBean>();
	     
	     
	     
	     try {
	            Class.forName("com.ibm.db2.jcc.DB2Driver");
	            try {
	                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
	                System.out.println("Connection established with the Database. ");
	            } catch(SQLException e) {
	                e.printStackTrace();
	            }
	        } catch(ClassNotFoundException e) {
	            e.printStackTrace();
	        }

	     
	     try{
	    	 String FilePath = "C:/178711_1.xlsx";
	            FileInputStream fs = new FileInputStream(FilePath);
	            Workbook workbook =  new XSSFWorkbook(fs);
	            Sheet sheet = workbook.getSheetAt(0);
	            int totalNoOfRows = 469;	            
	            for (int r = 0; r < totalNoOfRows; r++) {
	            	Row row=sheet.getRow(r);
	            	int col=0;
	            	Cell cell=row.getCell(col);
	            	 DataFormatter formatter = new DataFormatter();
                     String pin = formatter.formatCellValue(cell);
                     
                     if(con != null) {
                         try {
                        	 if(pin!=null) {
                        		 
                        		 StringBuilder queryForNode = new StringBuilder();
                        		 MaintainceBean dm = new MaintainceBean();
                        		 dm.setPin(""+pin.toString().trim());
                        		 queryForNode.append("SELECT DISTINCT(TRM_NUM),EQIP_ID,EQIP_NM FROM U90JLKP.NN_TRM_DTL WHERE TRM_NUM = '" + dm.getPin().toString().trim());
                                 queryForNode.append("' WITH UR FOR READ ONLY;");                        		
                                 
                                 System.out.println(queryForNode.toString());
                                 stmt = con.createStatement();
                                 rs =stmt.executeQuery(queryForNode.toString());
                                 if (rs.next()) {
                                	 
                                	 dm.setMachId(rs.getString("EQIP_ID"));
                                	 dm.setMachineNM(rs.getString("EQIP_NM"));  
                                	 
                                 }
                                 list1.add(dm);
                                 stmt.close();
                                 rs.close();
                        	 }
                        	 
                         }catch(Exception e) {
                             e.printStackTrace();
                         }
                     }
	            	
	            }
	            
	            System.out.println(list1.size());
	     }catch (IOException e){
	            e.printStackTrace();
	     }
	     //-------------------------------------------------------------------------------------------------------------------
	     
	     if(con != null) {
	    	 try{
	    		 for (MaintainceBean dm:list1) {
	    			 if(dm.getMachId()!=null){
	    				 StringBuilder queryForNode = new StringBuilder();
	    				 queryForNode.append("SELECT DISTINCT(MHF.MACH_ID_NUM),MHF.MACH_ID,MHF.MACH_NM,MHF.NODE_ID FROM U90EDMP.MACH_INFO MHF WHERE MHF.MACH_ID = '"+dm.getMachId().toString().trim());
                         queryForNode.append("' WITH UR FOR READ ONLY;");
		    			 
		    			 System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 dm.setNodeId(""+rs.getInt("NODE_ID"));
	                     }
	    			 }
	    			 
                     list2.add(dm);
                     
                     stmt.close();
                     rs.close();
	    		 }
	    		 System.out.println(list2.size());
	    		 
	    	 }catch(Exception e) {
                 e.printStackTrace();
             }
	    	 
	     }
	     
	//------------------------------------------------------------------------------------------
	     
	     if(con != null) {
	    	 try{
	    		 for (MaintainceBean dm:list2) {
	    			 if(dm.getMachId()!=null){
	    				 StringBuilder queryForNode = new StringBuilder();
		    			 queryForNode.append("SELECT * FROM U90JLKP.THRD_PRTY_ACSS WHERE EQIP_ID ="+dm.getMachId().toString().trim());
		    			 queryForNode.append(" AND ACTV_IND = 'Y' WITH UR FOR READ ONLY;");
		    			 
		    			 System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 dm.setAccountId(""+rs.getInt("ORG_ID"));
	                     }
	    			 }
	    			 
                     list3.add(dm);
                     
                     stmt.close();
                     rs.close();
	    		 }
	    		 System.out.println(list3.size());
	    		 
	    	 }catch(Exception e) {
                 e.printStackTrace();
             }
	    	 
	     }
	     
	//------------------------------------------------------------------------------------------
	     
	     if(con != null) {
	    	 try{
	    		 for (MaintainceBean dm:list3) {
	    			 if(dm.getAccountId()!=null){
	    				 StringBuilder queryForNode = new StringBuilder();
		    			 queryForNode.append("SELECT * FROM U90JLKP.ORG_ACCT WHERE ID="+dm.getAccountId().toString().trim());
		    			 queryForNode.append(" WITH UR FOR READ ONLY;");
		    			 
		    			 System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 dm.setAccountNm(""+rs.getString("ORG_NM"));
	                     } 
	    			 }	    			
                     list4.add(dm);
                     
                     stmt.close();
                     rs.close();
	    		 }
	    		 System.out.println(list4.size());
	    		 
	    	 }catch(Exception e) {
                 e.printStackTrace();
             }
	    	 
	     }
	     
	//------------------------------------------------------------------------------------------
	    if(con != null) {
	    	 try{
	    		 for (MaintainceBean dm:list4) {
	    			 if(dm.getMachId()!=null){
	    				 StringBuilder grpNm = new StringBuilder();
		    			 StringBuilder queryForNode = new StringBuilder();
		    			 queryForNode.append("SELECT * FROM U90EDMP.MACH_GRP_DM MGD LEFT JOIN U90EDMP.MACH_GRP_MACH MGM ON MGD.MACH_GRP_ID = MGM.MACH_GRP_ID WHERE MGM.MACH_ID ="+dm.getMachId().toString().trim());
		    			 queryForNode.append(" WITH UR FOR READ ONLY;");
		    			 
		    			 System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 if(grpNm.length()>0){
	                    		 grpNm.append(",");
	                    	 }                    	 
	                    	 grpNm.append(rs.getString("MACH_GRP_NM"));              
	                     }
	                     System.out.println(grpNm.toString());
	                     dm.setEquipGrpNm(grpNm.toString());
	    			 }   		
                     
                     list5.add(dm);
                     
                     stmt.close();
                     rs.close();
	    		 }
	    		 System.out.println(list5.size());
	    		 
	    	 }catch(Exception e) {
                 e.printStackTrace();
             }
	    	 
	     } 
	     
	//------------------------------------------------------------------------------------------
	     
	     if(con != null) {
	    	 try{
	    		 for (MaintainceBean dm:list5) {
	    			 if(dm.getNodeId()!=null){
	    				 int nodeId=Integer.parseInt(dm.getNodeId());
	    				 StringBuilder queryForNode = new StringBuilder();
	    				 if(nodeId<=10){	    					 
	    					 int actnode=nodeId-1;
	    					 queryForNode.append("SELECT * FROM J9000"+actnode+"P");
	    					 queryForNode.append(".EQIP_ENGN_HOURS WHERE MACH_ID = "+dm.getMachId().toString().trim());
	    					 queryForNode.append(" ORDER BY CPTR_TS DESC FETCH FIRST ROWS ONLY;");
	    				 }else if(nodeId>=11){
	    					 int actnode=nodeId-1;
	    					 queryForNode.append("SELECT * FROM J900"+actnode+"P");
	    					 queryForNode.append(".EQIP_ENGN_HOURS WHERE MACH_ID = "+dm.getMachId().toString().trim());
	    					 queryForNode.append(" ORDER BY CPTR_TS DESC FETCH FIRST ROWS ONLY;");
	    				 }
	    				 
		    			 
		    			 System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	dm.setEngineHrs(""+rs.getDouble("END_ENGN_HOURS"));
	                    	dm.setLastUpdatedTs(rs.getString("MOD_TS"));
	                     } 
	    			 }	    			
	    			 list6.add(dm);
                     
                     stmt.close();
                     rs.close();
	    		 }
	    		 System.out.println(list6.size());
	    		 
	    	 }catch(Exception e) {
                 e.printStackTrace();
             }
	    	 
	     }
	     
	//------------------------------------------------------------------------------------------
	     
	     if(con != null) {
	    	 try{
	    		 for (MaintainceBean dm:list6) {
	    			 if(dm.getMachId()!=null){
	    				 StringBuilder grpNm = new StringBuilder();
		    			 StringBuilder queryForNode = new StringBuilder();
		    			 queryForNode.append("SELECT * FROM U90EDMP.MACH_GRP_DM MGD LEFT JOIN U90EDMP.MACH_GRP_MACH MGM ON MGD.MACH_GRP_ID = MGM.MACH_GRP_ID WHERE MGM.MACH_ID ="+dm.getMachId().toString().trim());
		    			 queryForNode.append(" WITH UR FOR READ ONLY;");
		    			 
		    			 System.out.println(queryForNode.toString());
	                     stmt = con.createStatement();
	                     rs =stmt.executeQuery(queryForNode.toString());
	                     
	                     if (rs.next()) {
	                    	 if(grpNm.length()>0){
	                    		 grpNm.append(",");
	                    	 }                    	 
	                    	 grpNm.append(rs.getString("MACH_GRP_NM"));              
	                     }
	                     System.out.println(grpNm.toString());
	                     dm.setEquipGrpNm(grpNm.toString());
	    			 }   		
                     
                     list7.add(dm);
                     
                     stmt.close();
                     rs.close();
	    		 }
	    		 System.out.println(list7.size());
	    		 
	    	 }catch(Exception e) {
                 e.printStackTrace();
             }
	    	 
	     } 
	     
	//------------------------------------------------------------------------------------------
	     try{
	            String FILE_PATH = "C:/Machine Data.xlsx";
	            Workbook workbook = new XSSFWorkbook();

	            Sheet sheet = workbook.createSheet("report");

	            Row row;
	            int rowid = 0;
	           
	            row = sheet.createRow(rowid++);

	            row.createCell(0).setCellValue("MACH_ID");
	            row.createCell(1).setCellValue("PIN");
	            row.createCell(2).setCellValue("MACHINE NAME");
	            row.createCell(3).setCellValue("THIRD PARTY DEALER");
	            row.createCell(4).setCellValue("EQUIPMENT GROUPS");
	            row.createCell(5).setCellValue("ENGINE HOURS");
	            row.createCell(6).setCellValue("LAST UPDATED TIME STAMP");
	           
	            for (MaintainceBean dm:list7) {
	                row = sheet.createRow(rowid++);
	                row.createCell(0).setCellValue(dm.getMachId());
	                row.createCell(1).setCellValue(dm.getPin());
	                row.createCell(2).setCellValue(dm.getMachineNM());
	                row.createCell(3).setCellValue(dm.getAccountNm());
	                row.createCell(4).setCellValue(dm.getEquipGrpNm());
	                row.createCell(5).setCellValue(dm.getEngineHrs());
	                row.createCell(6).setCellValue(dm.getLastUpdatedTs());	               
	            }

	            try {
	                FileOutputStream fos = new FileOutputStream(FILE_PATH);
	                workbook.write(fos);
	                fos.close();

	                System.out.println(FILE_PATH + " is successfully written");
	            } catch (FileNotFoundException e) {
	                e.printStackTrace();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }

	        }catch (Exception e){
	        	e.printStackTrace();
	        }
	}

}
