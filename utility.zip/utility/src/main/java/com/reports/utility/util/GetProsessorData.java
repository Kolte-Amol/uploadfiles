/**
 * 
 */
package com.reports.utility.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.reports.utility.beans.ProcessorBean;


/**
 * @author BK93287
 *
 */
public class GetProsessorData {
	
	 public static void main(String args[]){
	        Connection con = null;
	        Statement stmt = null;
	        ResultSet rs = null;
	        List<ProcessorBean> processorBeanList=new ArrayList<ProcessorBean>();
	        List<ProcessorBean> processorBeanupdatedList=new ArrayList<ProcessorBean>();
	        try {
	            Class.forName("com.ibm.db2.jcc.DB2Driver");
	            try {
	                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
	                System.out.println("Connection established with the Database. ");
	            } catch(SQLException e) {
	                e.printStackTrace();
	            }
	        } catch(ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        
	        if(con != null){
	        	try {
	        		StringBuilder queryForNode = new StringBuilder();
	        		queryForNode.append("SELECT TRM_ID,TRM_NUM,DVC_TYP,ACTVN_DT,PIN,LCNSE_TYP_ID,LCNSE_EXPR_TS,HDWR_CO_ACTVN_TS FROM ");
	        		queryForNode.append("U90JLKP.NN_TRM_DTL WHERE DVC_TYP = 'GSix_4100_Processor' ");
	        		queryForNode.append("ORDER BY TRM_NUM  WITH UR FOR READ ONLY");
	        		
	        		 stmt = con.createStatement();
	                 rs = stmt.executeQuery(queryForNode.toString());
	                 while(rs.next()){
	                	 ProcessorBean pb = new ProcessorBean();
	                	 pb.setTrmId(rs.getString("TRM_ID"));
	                	 pb.setTrmNum(rs.getString("TRM_NUM"));
	                	 pb.setDeviceType(rs.getString("DVC_TYP"));
	                	 pb.setActivationDt(rs.getString("ACTVN_DT"));
	                	 pb.setPin(rs.getString("PIN"));
	                	 pb.setLicenseTypeId(rs.getString("LCNSE_TYP_ID"));
	                	 pb.setLicenseExpTs(rs.getString("LCNSE_EXPR_TS"));
	                	 pb.setHdwrCOActTs(rs.getString("HDWR_CO_ACTVN_TS"));
	                	 
	                	 processorBeanList.add(pb);
	                 }
	                 stmt.close();
	                 rs.close();
	                 System.out.println(processorBeanList.size());
	        		
	        	}catch(Exception e) {
	                e.printStackTrace();
	            }
	        }
	        
	        if(con != null){
	        	try {
	        		 for (ProcessorBean pb:processorBeanList) {
	        			 if(pb.getTrmId()!=null){ 
	        				StringBuilder queryForNode = new StringBuilder();
	     	        		queryForNode.append("SELECT DISTINCT(VER_NM),DVC_ID,VER_ID,STATUS,INST_TS,LAST_CFIRM_TS,MOD_TS,VER_TYP_ID FROM ");
	     	        		queryForNode.append("U90EDMP.TRM_VER_HIST_SMRY WHERE ");
	     	        		queryForNode.append("DVC_ID = "+pb.getTrmId().toString().trim());
	     	        		queryForNode.append(" AND STATUS = 'C'");
	     	        		queryForNode.append(" AND VER_TYP_ID = 6");
	     	        		queryForNode.append(" WITH UR FOR READ ONLY");
	     	        		
	     	        		 stmt = con.createStatement();
	     	        		 System.out.println(queryForNode.toString());
	    	                 rs = stmt.executeQuery(queryForNode.toString());
	    	                 while(rs.next()){
	    	                	 pb.setVerId(rs.getString("VER_ID"));
	    	                	 pb.setVerNm(rs.getString("VER_NM"));
	    	                	 pb.setStatus(rs.getString("STATUS"));
	    	                	 pb.setInstTs(rs.getString("INST_TS"));
	    	                	 pb.setLstCnfTs(rs.getString("LAST_CFIRM_TS"));
	    	                	 pb.setModTs(rs.getString("MOD_TS"));
	    	                 }
	    	                 processorBeanupdatedList.add(pb);
	        			 }
	        		 }
	        		 stmt.close();
	                 rs.close();
	                 System.out.println(processorBeanupdatedList.size());
	        	}catch(Exception e) {
	                e.printStackTrace();
	            }
	        }
	 }

}
