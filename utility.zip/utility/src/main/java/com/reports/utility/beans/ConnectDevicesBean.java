/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class ConnectDevicesBean {
	
	private String trmId;
    private String trmNum;
    private String eqipId;
    private String registration;
    private String coId;
    private String deviceType;
    private String activationDt;
    private String pin;
    private String licenseTypeId;
	private String licenseExpTs;
	private String hdwrCOActTs;
	private String nodeId;
	private String lastCallinTS;
	private String hdwrPkgID;
	
	
	
	
	public String getTrmId() {
		return trmId;
	}
	public void setTrmId(String trmId) {
		this.trmId = trmId;
	}
	public String getTrmNum() {
		return trmNum;
	}
	public void setTrmNum(String trmNum) {
		this.trmNum = trmNum;
	}
	public String getEqipId() {
		return eqipId;
	}
	public void setEqipId(String eqipId) {
		this.eqipId = eqipId;
	}
	public String getRegistration() {
		return registration;
	}
	public void setRegistration(String registration) {
		this.registration = registration;
	}
	public String getCoId() {
		return coId;
	}
	public void setCoId(String coId) {
		this.coId = coId;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getActivationDt() {
		return activationDt;
	}
	public void setActivationDt(String activationDt) {
		this.activationDt = activationDt;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getLicenseTypeId() {
		return licenseTypeId;
	}
	public void setLicenseTypeId(String licenseTypeId) {
		this.licenseTypeId = licenseTypeId;
	}
	public String getLicenseExpTs() {
		return licenseExpTs;
	}
	public void setLicenseExpTs(String licenseExpTs) {
		this.licenseExpTs = licenseExpTs;
	}
	public String getHdwrCOActTs() {
		return hdwrCOActTs;
	}
	public void setHdwrCOActTs(String hdwrCOActTs) {
		this.hdwrCOActTs = hdwrCOActTs;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getLastCallinTS() {
		return lastCallinTS;
	}
	public void setLastCallinTS(String lastCallinTS) {
		this.lastCallinTS = lastCallinTS;
	}
	public String getHdwrPkgID() {
		return hdwrPkgID;
	}
	public void setHdwrPkgID(String hdwrPkgID) {
		this.hdwrPkgID = hdwrPkgID;
	}
	
	
	
}
