package com.reports.utility.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.reports.utility.beans.demobean;


/**
 * Created by Bk93287 on 7/28/2016.
 */
public class GetdatafromDB {
    public static void main(String args[]){
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        List<demobean> demobeanList=new ArrayList<demobean>();
        List<demobean> list1=new ArrayList<demobean>();
        List<demobean> list2=new ArrayList<demobean>();
        List<demobean> list3=new ArrayList<demobean>();

        try {
            Class.forName("com.ibm.db2.jcc.DB2Driver");
            try {
                con = DriverManager.getConnection("jdbc:db2://db223.dx.deere.com:5150/DB223", "A904093", "r9tku1qd");
                System.out.println("Connection established with the Database. ");
            } catch(SQLException e) {
                e.printStackTrace();
            }
        } catch(ClassNotFoundException e) {
            e.printStackTrace();
        }

        if(con != null){
            try {

                    StringBuilder queryForNode = new StringBuilder();
                    queryForNode.append("SELECT DISTINCT(CMGTY.COMM_GTWY_ID),CMGTY.GTWY_TYP_ID,CMGTY.IMEI,CMGTY.ICCID,CMGTY.MSISDN,CMGTY.IMSI,");
                    queryForNode.append("GTXR.COMM_GTWY_ID,GTXR.HDWR_PKG_ID,");
                    queryForNode.append("NTDL.TRM_ID,NTDL.TRM_NUM,NTDL.COMAR_ORD_NUM,NTDL.EQIP_ID,NTDL.RGSTN_DSC,NTDL.CO_ID,NTDL.PIN,NTDL.HDWR_PKG_ID FROM U90EDMP.COMM_GTWY CMGTY JOIN U90EDMP.HDWR_PKG_GTWY_XREF GTXR ON CMGTY.COMM_GTWY_ID = GTXR.COMM_GTWY_ID ");
                    queryForNode.append("JOIN U90JLKP.NN_TRM_DTL NTDL ON GTXR.HDWR_PKG_ID = NTDL.HDWR_PKG_ID ");
                    queryForNode.append("WHERE NTDL.CO_ID IN (148501, 232092, 242470, 242471, 246783, 264785, 273582, 273583, 275217, 277561, 277596, 279981, 281520, 282050) ORDER BY NTDL.TRM_NUM ASC, NTDL.CO_ID ASC WITH UR FOR READ ONLY;");

                    stmt = con.createStatement();
                    rs = stmt.executeQuery(queryForNode.toString());
                    while(rs.next()){
                        demobean dm=new demobean();
                        dm.setGetwayId(rs.getString("COMM_GTWY_ID"));
                        dm.setGetwayType(rs.getString("GTWY_TYP_ID"));
                        dm.setImei(rs.getString("IMEI"));
                        dm.setIccid(rs.getString("ICCID"));
                        dm.setMsisdn(rs.getString("MSISDN"));
                        dm.setImsi(rs.getString("IMSI"));
                        dm.setTrmid(rs.getString("TRM_ID"));
                        dm.setTrmnum(rs.getString("TRM_NUM"));
                        dm.setEqipid(rs.getString("EQIP_ID"));
                        dm.setRegistration(rs.getString("RGSTN_DSC"));
                        dm.setCoid(rs.getString("CO_ID"));
                        dm.setPin(rs.getString("PIN"));
              //          System.out.println(dm.getGetwayId());
                        demobeanList.add(dm);
                    }
                stmt.close();
                rs.close();
                System.out.println(demobeanList.size());

            } catch(Exception e) {
                e.printStackTrace();
            }
        }
        if(con != null) {
            try {
                for (demobean dm:demobeanList) {
                    if(dm.getEqipid()!=null) {
                        StringBuilder queryForNode = new StringBuilder();
                        queryForNode.append("SELECT DISTINCT(VH.VER_NM) FROM U90EDMP.TRM_VER_HIST_SMRY VH WHERE VH.DVC_ID =" + dm.getTrmid().toString().trim());
                        queryForNode.append(" AND VH.VER_TYP_ID = 1 AND VH.STATUS = 'C' WITH UR FOR READ ONLY;");

                        stmt = con.createStatement();
                        rs = stmt.executeQuery(queryForNode.toString());

                        if (rs.next()) {
                            dm.setConfig(rs.getString("VER_NM"));
                        }
                    }
                    list1.add(dm);
                }

                stmt.close();
                rs.close();
                System.out.println(list1.size());
            }catch(Exception e) {
                e.printStackTrace();
            }
        }

        if(con != null) {
            try {
                for (demobean dm:list1) {
                    if(dm.getEqipid()!=null){
                        StringBuilder queryForNode = new StringBuilder();
                        queryForNode.append("SELECT MF.NODE_ID FROM U90EDMP.MACH_INFO MF WHERE MF.MACH_ID ="+dm.getEqipid().toString().trim());
                        queryForNode.append(" WITH UR FOR READ ONLY;");

                        stmt = con.createStatement();
                        rs = stmt.executeQuery(queryForNode.toString());

                        if(rs.next()){
                            dm.setNodeId(rs.getString("NODE_ID"));
                        }
                    }
                    list2.add(dm);
                }
                stmt.close();
                rs.close();
                System.out.println(list2.size());
            }catch(Exception e) {
                e.printStackTrace();
            }
        }

        if(con != null) {
            try {
                for (demobean dm:list1) {
                    if(dm.getNodeId()!=null){
                        int nodeid=Integer.parseInt(dm.getNodeId().toString().trim());
                        StringBuilder nodename = new StringBuilder();
                        if(nodeid<11){
                            nodename.append("J9000"+(nodeid-1));
                            nodename.append("P");
                        }else{
                            nodename.append("J900"+(nodeid-1));
                            nodename.append("P");
                        }

                        StringBuilder queryForNode = new StringBuilder();
                        queryForNode.append("SELECT * FROM "+nodename.toString().trim());
                        queryForNode.append(".EQIP_CALL_IN_INFO ECL WHERE ECL.MACH_ID="+dm.getEqipid().toString().trim());
                        queryForNode.append(" AND ECL.GTWY_TYP_ID ="+dm.getGetwayType().toString().trim());
                        queryForNode.append(" order by ECL.CPTR_TS desc fetch first row only;");

                        stmt = con.createStatement();

                        rs = stmt.executeQuery(queryForNode.toString());

                        if(rs.next()){
                            dm.setLastcommtp(rs.getString("CPTR_TS"));
                        }
                    }
                    list3.add(dm);
                }
                stmt.close();
                rs.close();
                System.out.println(list3.size());
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
        try{
            String FILE_PATH = "C:/Brazil report.xlsx";
            Workbook workbook = new XSSFWorkbook();

            Sheet sheet = workbook.createSheet("report");
            //Create row object
            Row row;
            int rowid = 0;
            row = sheet.createRow(rowid++);

            row.createCell(0).setCellValue("getwayId");
            row.createCell(1).setCellValue("getwayType");
            row.createCell(2).setCellValue("imei");
            row.createCell(3).setCellValue("iccid");
            row.createCell(4).setCellValue("msisdn");
            row.createCell(5).setCellValue("imsi");
            row.createCell(6).setCellValue("trmid");
            row.createCell(7).setCellValue("trmnum");
            row.createCell(8).setCellValue("eqipid");
            row.createCell(9).setCellValue("reg");
            row.createCell(10).setCellValue("coid");
            row.createCell(11).setCellValue("pin");
            row.createCell(12).setCellValue("config");
            row.createCell(13).setCellValue("last comm");

            for (demobean dm:list3) {
                row = sheet.createRow(rowid++);
                row.createCell(0).setCellValue(dm.getGetwayId());
                row.createCell(1).setCellValue(dm.getGetwayType());
                row.createCell(2).setCellValue(dm.getImei());
                row.createCell(3).setCellValue(dm.getIccid());
                row.createCell(4).setCellValue(dm.getMsisdn());
                row.createCell(5).setCellValue(dm.getImsi());
                row.createCell(6).setCellValue(dm.getTrmid());
                row.createCell(7).setCellValue(dm.getTrmnum());
                row.createCell(8).setCellValue(dm.getEqipid());
                row.createCell(9).setCellValue(dm.getRegistration());
                row.createCell(10).setCellValue(dm.getCoid());
                row.createCell(11).setCellValue(dm.getPin());
                row.createCell(12).setCellValue(dm.getConfig());
                row.createCell(13).setCellValue(dm.getLastcommtp());
            }

            try {
                FileOutputStream fos = new FileOutputStream(FILE_PATH);
                workbook.write(fos);
                fos.close();

                System.out.println(FILE_PATH + " is successfully written");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }catch (Exception e){

        }

    }
}
