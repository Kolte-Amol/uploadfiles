/**
 * 
 */
package com.reports.utility.beans;

/**
 * @author BK93287
 *
 */
public class ConfigBean {

	private String dvcid;
	private String trmNum;
	private String configGUID;
	private String instTS;
	/**
	 * @return the dvcid
	 */
	public String getDvcid() {
		return dvcid;
	}
	/**
	 * @param dvcid the dvcid to set
	 */
	public void setDvcid(String dvcid) {
		this.dvcid = dvcid;
	}
	/**
	 * @return the trmNum
	 */
	public String getTrmNum() {
		return trmNum;
	}
	/**
	 * @param trmNum the trmNum to set
	 */
	public void setTrmNum(String trmNum) {
		this.trmNum = trmNum;
	}
	/**
	 * @return the configGUID
	 */
	public String getConfigGUID() {
		return configGUID;
	}
	/**
	 * @param configGUID the configGUID to set
	 */
	public void setConfigGUID(String configGUID) {
		this.configGUID = configGUID;
	}
	/**
	 * @return the instTS
	 */
	public String getInstTS() {
		return instTS;
	}
	/**
	 * @param instTS the instTS to set
	 */
	public void setInstTS(String instTS) {
		this.instTS = instTS;
	}
	
}
