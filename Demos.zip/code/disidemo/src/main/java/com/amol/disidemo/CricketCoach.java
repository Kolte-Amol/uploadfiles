/**
 * 
 */
package com.amol.disidemo;

/**
 * @author bhagwat.kolte
 *
 */
public class CricketCoach implements Coach {
	
	private FortuneService fortuneService;
	
	private String emailAddress;
	private String team;
	
	
	/**
	 * No arg constructor
	 */
	public CricketCoach() {
		super();
		
		System.out.println("Inside Constructor method");
	}
	
	

	/**
	 * @return the fortuneService
	 */
//	public FortuneService getFortuneService() {
//		return fortuneService;
//	}

	
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}



	/**
	 * @return the team
	 */
	public String getTeam() {
		return team;
	}



	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		System.out.println("Inside setter email address method");
		this.emailAddress = emailAddress;
	}



	/**
	 * @param team the team to set
	 */
	public void setTeam(String team) {
		System.out.println("Inside setter team method");
		this.team = team;
	}



	/**
	 * @param fortuneService the fortuneService to set
	 */
	public void setFortuneService(FortuneService fortuneService) {
		System.out.println("Inside setter Fortune method");
		this.fortuneService = fortuneService;
	}

	/* (non-Javadoc)
	 * @see com.amol.disidemo.Coach#getDailyWorkout()
	 */
	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		
		System.out.println(getEmailAddress().toString());
		System.out.println(getTeam().toString());
		return "Do Batting properly";
	}

	/* (non-Javadoc)
	 * @see com.amol.disidemo.Coach#getFortune()
	 */
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
	//	return getFortuneService().getFortune();
		
		return fortuneService.getFortune();
	}

}
