package com.amol.disidemo;

public interface Coach {

	public String getDailyWorkout();
	
	public String getFortune();
	
}
