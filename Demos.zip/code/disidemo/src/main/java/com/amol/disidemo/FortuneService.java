/**
 * 
 */
package com.amol.disidemo;

/**
 * @author bhagwat.kolte
 *
 */
public interface FortuneService {

	public String getFortune();
}
