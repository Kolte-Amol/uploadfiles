/**
 * 
 */
package com.amol.dicidemo;

/**
 * @author bhagwat.kolte
 *
 */
public interface FortuneService {

	public String getFortune();
}
