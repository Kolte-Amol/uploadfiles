package com.amol.dicidemo;

public class BaseballCoach implements Coach {
	
	private FortuneService fortuneService;
	
	
	
	/**
	 * @param fortuneService
	 */
	public BaseballCoach(FortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}



	@Override
	public String getDailyWorkout() {
		return "Spend 30 minutes on batting practice";
	}



	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return fortuneService.getFortune();
	}

}








