package com.amol.dicidemo;

public interface Coach {

	public String getDailyWorkout();
	
	public String getFortune();
	
}
