/**
 * 
 */
package com.amol.janotndemo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author bhagwat.kolte
 *
 */
@Component
@Scope("prototype")
public class TennisCoach implements Coach {

	/* (non-Javadoc)
	 * @see com.amol.janotndemo.Coach#getDailyWorkout()
	 */
	@Override
	public String getDailyWorkout() {
		return "Practice in backend";
	}

}
