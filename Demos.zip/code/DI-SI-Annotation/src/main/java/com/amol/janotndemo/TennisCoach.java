/**
 * 
 */
package com.amol.janotndemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author bhagwat.kolte
 *
 *
 *Default beanid same as class name with first letter in lower case
 *
 */
@Component
public class TennisCoach implements Coach {

	private FortuneService fortuneService;
		
	/**
	 * 
	 */
	public TennisCoach() {
		super();
	}

	
	/**
	 * @return the fortuneService
	 */
	public FortuneService getFortuneService() {
		return fortuneService;
	}


	/**
	 * @param fortuneService the fortuneService to set
	 */
	@Autowired
	public void setFortuneService(FortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}


	/* (non-Javadoc)
	 * @see com.amol.janotndemo.Coach#getDailyWorkout()
	 */
	@Override
	public String getDailyWorkout() {
		return "Practice in backend";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}
