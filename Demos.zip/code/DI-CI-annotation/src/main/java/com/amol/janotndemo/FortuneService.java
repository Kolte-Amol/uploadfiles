/**
 * 
 */
package com.amol.janotndemo;

/**
 * @author bhagwat.kolte
 *
 */
public interface FortuneService {

	public String getFortune();
}
