/**
 * 
 */
package com.amol.janotndemo;

import org.springframework.stereotype.Component;

/**
 * @author bhagwat.kolte
 *
 */
@Component
public class HappyFortuneService implements FortuneService {

	/* (non-Javadoc)
	 * @see com.amol.dicidemo.FortuneService#getFortune()
	 */
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return "Today is your lucky day!!!!!!";
	}

}
