package com.amol.janotndemo;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
		
}
