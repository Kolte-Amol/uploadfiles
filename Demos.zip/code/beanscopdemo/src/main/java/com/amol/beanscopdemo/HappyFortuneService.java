/**
 * 
 */
package com.amol.beanscopdemo;

/**
 * @author bhagwat.kolte
 *
 */
public class HappyFortuneService implements FortuneService {

	/* (non-Javadoc)
	 * @see com.amol.dicidemo.FortuneService#getFortune()
	 */
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return "Today is your lucky day!!!!!!";
	}

}
