/**
 * 
 */
package com.amol.beanscopdemo;

/**
 * @author bhagwat.kolte
 *
 */
public interface FortuneService {

	public String getFortune();
}
