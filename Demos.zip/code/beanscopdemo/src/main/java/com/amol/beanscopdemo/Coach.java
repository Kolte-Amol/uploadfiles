package com.amol.beanscopdemo;

public interface Coach {

	public String getDailyWorkout();
	
	public String getFortune();
	
}
