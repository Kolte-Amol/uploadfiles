package com.java.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class HelloSpringBootJspApplication {
	
	
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(HelloSpringBootJspApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(HelloSpringBootJspApplication.class, args);
	}
}
