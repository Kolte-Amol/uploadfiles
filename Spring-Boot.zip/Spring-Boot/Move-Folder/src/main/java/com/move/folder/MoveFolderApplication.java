package com.move.folder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.move.folder.service.MoveFolderService;

@SpringBootApplication
public class MoveFolderApplication implements CommandLineRunner{
	
	@Autowired
	MoveFolderService moveFolderService;

	public static void main(String[] args) {
		
		SpringApplication app = new SpringApplication(MoveFolderApplication.class);
		//SpringApplication.run(MoveFolderApplication.class, args);		
		app.run(args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		
		System.out.println(moveFolderService.moveFolder());
	    System.exit(0);
		
	}
}
