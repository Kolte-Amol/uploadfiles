/**
 * 
 */
package com.move.folder.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;

/**
 * @author Bk93287
 *
 */
@Service
public class MoveFolderService {
	
	public boolean moveFolder(){
		 String source = "C:/spring boot docs/Spring boot";
	        File srcDir = new File(source);

	        String destination = "H:/spring boot docs/Spring boot";
	        File destDir = new File(destination);

	        try {
	        	 FileUtils.moveDirectory(srcDir, destDir);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
	     makeNewFolder();
	        
		return true;
		
	}
	
	public void makeNewFolder(){
		Date localDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        System.out.println(formatter.format(localDate));
		
		File files = new File("C:\\spring boot docs\\"+formatter.format(localDate));
		
		 if (!files.exists()) {
	            if (files.mkdirs()) {
	                System.out.println("Multiple directories are created!");
	            } else {
	                System.out.println("Failed to create multiple directories!");
	            }
	        }
	}

}
