package com.amol.iocdemo;

public interface Coach {

	public String getDailyWorkout();
	
}
