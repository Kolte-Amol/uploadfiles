/**
 * 
 */
package com.amol.janotndemo;

import org.springframework.stereotype.Component;

/**
 * @author bhagwat.kolte
 *
 */
@Component("thatSillyCoach")
public class TennisCoach implements Coach {

	/* (non-Javadoc)
	 * @see com.amol.janotndemo.Coach#getDailyWorkout()
	 */
	@Override
	public String getDailyWorkout() {
		return "Practice in backend";
	}

}
